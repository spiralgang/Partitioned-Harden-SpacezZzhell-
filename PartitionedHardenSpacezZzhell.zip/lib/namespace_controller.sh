#!/system/bin/sh
# Namespace Controller Library
# Manages Linux namespaces for container isolation

# Create a fully isolated namespace environment
create_isolated_namespace() {
    local ns_name="$1"
    
    # Check kernel capabilities for namespaces
    if ! unshare --help >/dev/null 2>&1; then
        log_error "unshare command not available"
        return 1
    fi
    
    # Check if USER namespace is supported (critical for full isolation)
    if ! grep -q "user_namespace" /proc/kallsyms; then
        log_warn "USER namespace not supported by kernel, isolation will be partial"
    fi
    
    # Create namespace script
    local ns_script="${HAIF_BIN}/ns_${ns_name}"
    cat > "${ns_script}" << EOF
#!/system/bin/sh
# Set hostname in the new UTS namespace
hostname ${ns_name}

# Mount private /proc to avoid information leakage
mount -t proc proc /proc

# Ensure /dev is properly set up
mount -t tmpfs tmpfs /dev
mkdir -p /dev/pts
mount -t devpts devpts /dev/pts

# Continue to init process
exec "\$@"
EOF
    chmod +x "${ns_script}"
    
    return 0
}

# Create isolated control group for resource constraints
create_isolated_cgroup() {
    local cgroup_name="$1"
    
    # Check if cgroups v2 is available (preferred)
    if [ -d "/sys/fs/cgroup/cgroup.controllers" ]; then
        # cgroups v2
        mkdir -p "/sys/fs/cgroup/${cgroup_name}"
        echo "+memory +cpu +io" > "/sys/fs/cgroup/${cgroup_name}/cgroup.subtree_control" 2>/dev/null || {
            log_error "Failed to set cgroup controllers"
            return 1
        }
        
        # Set up memory limits
        echo "2G" > "/sys/fs/cgroup/${cgroup_name}/memory.max" 2>/dev/null
        echo "1G" > "/sys/fs/cgroup/${cgroup_name}/memory.high" 2>/dev/null
        
        # Set up CPU limits
        echo "100000 100000" > "/sys/fs/cgroup/${cgroup_name}/cpu.max" 2>/dev/null
        
        log_info "Created cgroup v2: ${cgroup_name}"
    elif [ -d "/sys/fs/cgroup/memory" ]; then
        # cgroups v1
        mkdir -p "/sys/fs/cgroup/memory/${cgroup_name}"
        mkdir -p "/sys/fs/cgroup/cpu/${cgroup_name}"
        mkdir -p "/sys/fs/cgroup/devices/${cgroup_name}"
        
        # Memory limits
        echo "2G" > "/sys/fs/cgroup/memory/${cgroup_name}/memory.limit_in_bytes" 2>/dev/null
        echo "1G" > "/sys/fs/cgroup/memory/${cgroup_name}/memory.soft_limit_in_bytes" 2>/dev/null
        
        # CPU limits
        echo "100000" > "/sys/fs/cgroup/cpu/${cgroup_name}/cpu.cfs_quota_us" 2>/dev/null
        echo "100000" > "/sys/fs/cgroup/cpu/${cgroup_name}/cpu.cfs_period_us" 2>/dev/null
        
        # Device restrictions
        echo "a *:* rwm" > "/sys/fs/cgroup/devices/${cgroup_name}/devices.deny" 2>/dev/null
        
        log_info "Created cgroup v1: ${cgroup_name}"
    else
        log_warn "Cgroup filesystem not available"
        return 1
    fi
    
    return 0
}