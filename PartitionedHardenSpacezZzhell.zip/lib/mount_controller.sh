#!/system/bin/sh
# Mount Controller Library
# Manages mount namespaces and overlay filesystems

# Extract system image from Samsung firmware
extract_system_image() {
    local firmware_zip="$1"
    local output_path="$2"
    
    if [ ! -f "${firmware_zip}" ]; then
        log_error "Firmware file not found: ${firmware_zip}"
        return 1
    fi
    
    local extract_dir="${HAIF_ROOT}/tmp/extract"
    mkdir -p "${extract_dir}"
    
    log_info "Extracting firmware..."
    
    # Try extracting AP package first (Samsung firmware pattern)
    unzip -j "${firmware_zip}" "AP*.tar.md5" -d "${extract_dir}" 2>/dev/null
    
    # Find extracted tar file
    local tar_file=$(find "${extract_dir}" -name "*.tar.md5" | head -n1)
    
    if [ -n "${tar_file}" ]; then
        log_info "Extracting system image from ${tar_file}..."
        tar -xf "${tar_file}" -C "${extract_dir}" "system.img*" 2>/dev/null || {
            log_error "Failed to extract system.img from tar"
            return 1
        }
    else
        # Try direct extraction
        log_info "Trying direct system.img extraction..."
        unzip -j "${firmware_zip}" "system.img*" -d "${extract_dir}" 2>/dev/null || {
            log_error "Failed to extract system.img from firmware"
            return 1
        }
    fi
    
    # Handle lz4 compressed system image
    if [ -f "${extract_dir}/system.img.lz4" ]; then
        log_info "Decompressing system.img.lz4..."
        lz4 -d "${extract_dir}/system.img.lz4" "${extract_dir}/system.img" || {
            log_error "Failed to decompress system.img.lz4"
            return 1
        }
    fi
    
    # Handle sparse system image
    if [ -f "${extract_dir}/system.img" ]; then
        local file_type=$(file -b "${extract_dir}/system.img" 2>/dev/null || echo "unknown")
        if echo "${file_type}" | grep -q "sparse"; then
            log_info "Converting sparse image to raw..."
            simg2img "${extract_dir}/system.img" "${extract_dir}/system.img.raw" || {
                log_error "Failed to convert sparse image"
                return 1
            }
            mv "${extract_dir}/system.img.raw" "${extract_dir}/system.img"
        fi
    else
        log_error "No system.img found after extraction"
        return 1
    fi
    
    # Move to final location
    mv "${extract_dir}/system.img" "${output_path}" || {
        log_error "Failed to move system.img to destination"
        return 1
    }
    
    log_info "System image extraction complete"
    return 0
}

# Set up overlay filesystem
setup_overlay_fs() {
    local lower_dir="$1"
    local upper_dir="$2"
    local work_dir="$3"
    local mount_point="$4"
    
    if [ ! -d "${lower_dir}" ] || [ ! -d "${upper_dir}" ] || [ ! -d "${work_dir}" ] || [ ! -d "${mount_point}" ]; then
        log_error "Invalid overlay directories"
        return 1
    fi
    
    # Mount the overlay filesystem
    mount -t overlay overlay \
        -o lowerdir=${lower_dir},upperdir=${upper_dir},workdir=${work_dir} \
        ${mount_point} || {
        log_error "Failed to mount overlay filesystem"
        return 1
    }
    
    log_info "Overlay filesystem mounted at ${mount_point}"
    return 0
}

# Securely bind mount with proper isolation
secure_bind_mount() {
    local source="$1"
    local target="$2"
    local options="${3:-ro}"
    
    if [ ! -e "${source}" ]; then
        log_error "Source path does not exist: ${source}"
        return 1
    fi
    
    mkdir -p "${target}" 2>/dev/null
    
    # Determine if source is a directory or file
    if [ -d "${source}" ]; then
        mount --bind "${source}" "${target}" || {
            log_error "Failed to bind mount directory ${source} to ${target}"
            return 1
        }
    else
        # For files, create parent directory if needed
        mkdir -p "$(dirname "${target}")" 2>/dev/null
        touch "${target}" 2>/dev/null
        mount --bind "${source}" "${target}" || {
            log_error "Failed to bind mount file ${source} to ${target}"
            return 1
        }
    fi
    
    # Apply mount options (ro, noexec, etc.)
    if [ "${options}" != "rw" ]; then
        mount -o remount,${options} "${target}" || {
            log_error "Failed to remount with options: ${options}"
            return 1
        }
    fi
    
    log_info "Bind mounted ${source} to ${target} with options: ${options}"
    return 0
}