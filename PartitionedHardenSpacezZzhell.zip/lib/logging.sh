#!/system/bin/sh
# Logging Library
# Provides structured logging functionality

# Initialize logging
init_logging() {
    local log_file="$1"
    mkdir -p "$(dirname "${log_file}")" 2>/dev/null
    touch "${log_file}" 2>/dev/null || {
        echo "Unable to create log file: ${log_file}" >&2
        return 1
    }
    
    HAIF_LOG="${log_file}"
    return 0
}

# Log a message with timestamp and level
log_message() {
    local level="$1"
    local message="$2"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    echo "[${timestamp}] [${level}] ${message}" | tee -a "${HAIF_LOG}" >&2
}

# Log info level message
log_info() {
    log_message "INFO" "$1"
}

# Log warning level message
log_warn() {
    log_message "WARN" "$1"
}

# Log error level message
log_error() {
    log_message "ERROR" "$1"
}

# Log debug level message
log_debug() {
    if [ "${HAIF_DEBUG:-0}" -eq 1 ]; then
        log_message "DEBUG" "$1"
    fi
}