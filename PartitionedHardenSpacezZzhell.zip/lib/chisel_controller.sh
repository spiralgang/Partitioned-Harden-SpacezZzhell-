#!/system/bin/sh
# Chisel Controller Library
# Manages OCI-compatible containers with Chisel

# Initialize Chisel container runtime
init_chisel() {
    local chisel_version="v0.8.1"
    local arch=$(uname -m)
    
    if [ ! -f "${HAIF_BIN}/chisel" ]; then
        log_info "Downloading Chisel ${chisel_version}..."
        mkdir -p "${HAIF_BIN}"
        
        # Download Chisel binary
        curl -L "https://github.com/canonical/chisel/releases/download/${chisel_version}/chisel-${arch}" \
            -o "${HAIF_BIN}/chisel" || {
            log_error "Failed to download Chisel binary"
            return 1
        }
        
        chmod +x "${HAIF_BIN}/chisel"
        log_info "Chisel binary installed at ${HAIF_BIN}/chisel"
    fi
    
    # Verify Chisel installation
    if ! "${HAIF_BIN}/chisel" version >/dev/null 2>&1; then
        log_error "Chisel binary not functional"
        return 1
    fi
    
    return 0
}

# Create a Chisel container from the configuration
create_container() {
    local container_name="$1"
    local config_file="${HAIF_CONFIG}/container.json"
    
    if [ ! -f "${config_file}" ]; then
        log_error "Container configuration file not found: ${config_file}"
        return 1
    fi
    
    # Create container runtime directory
    local container_dir="${HAIF_ROOT}/containers/${container_name}"
    mkdir -p "${container_dir}"
    
    # Copy and customize container config
    cp "${config_file}" "${container_dir}/config.json"
    
    # Create container bundle
    mkdir -p "${container_dir}/rootfs"
    
    log_info "Container ${container_name} created"
    return 0
}

# Run a container with isolation
run_container() {
    local container_name="$1"
    local container_dir="${HAIF_ROOT}/containers/${container_name}"
    
    if [ ! -d "${container_dir}" ]; then
        log_error "Container not found: ${container_name}"
        return 1
    fi
    
    # Create state directory
    mkdir -p "${container_dir}/state"
    
    # Run the container using Chisel
    "${HAIF_BIN}/chisel" run \
        --bundle "${container_dir}" \
        --pid-file "${container_dir}/state/pid" \
        "${container_name}" || {
        log_error "Failed to run container ${container_name}"
        return 1
    }
    
    log_info "Container ${container_name} started"
    return 0
}