#!/system/bin/sh
# ZRAM Controller Library
# Optimized for Samsung devices with specialized ZRAM capabilities

# Set up a ZRAM device with specified parameters
setup_zram() {
    local size_kb="$1"
    local algorithm="${2:-lz4}"
    local priority="${3:-100}"
    
    # Check if ZRAM module is available
    if ! grep -q zram /proc/modules && ! modprobe zram num_devices=1; then
        log_error "ZRAM kernel module not available"
        return 1
    fi
    
    # Reset any existing ZRAM config
    if [ -e /dev/zram0 ]; then
        if grep -q /dev/zram0 /proc/swaps; then
            swapoff /dev/zram0 || log_warn "Failed to deactivate existing ZRAM"
        fi
        echo 1 > /sys/block/zram0/reset 2>/dev/null || log_warn "Failed to reset ZRAM device"
    fi
    
    # Configure ZRAM device
    echo "${algorithm}" > /sys/block/zram0/comp_algorithm 2>/dev/null || log_warn "Failed to set compression algorithm"
    echo "${size_kb}K" > /sys/block/zram0/disksize || {
        log_error "Failed to set ZRAM disk size"
        return 1
    }
    
    # Initialize swap on ZRAM device
    mkswap /dev/zram0 >/dev/null || {
        log_error "Failed to format ZRAM device as swap"
        return 1
    }
    
    # Activate ZRAM swap
    swapon -p "${priority}" /dev/zram0 || {
        log_error "Failed to activate ZRAM swap"
        return 1
    }
    
    # Samsung-specific optimizations
    apply_samsung_optimizations
    
    log_info "ZRAM initialized: ${size_kb}K with ${algorithm} compression"
    return 0
}

# Apply Samsung-specific ZRAM optimizations
apply_samsung_optimizations() {
    # Memory deduplication (Samsung-specific)
    if [ -f "/sys/block/zram0/use_dedup" ]; then
        echo 1 > /sys/block/zram0/use_dedup 2>/dev/null &&
            log_info "Enabled Samsung memory deduplication"
    fi
    
    # Max compression streams (set to CPU count)
    if [ -f "/sys/block/zram0/max_comp_streams" ]; then
        local cpu_count=$(grep -c processor /proc/cpuinfo)
        echo "${cpu_count}" > /sys/block/zram0/max_comp_streams 2>/dev/null &&
            log_info "Set compression streams to ${cpu_count}"
    fi
    
    # Compact ZRAM to reclaim memory (Samsung-specific)
    if [ -f "/sys/block/zram0/compact" ]; then
        echo 1 > /sys/block/zram0/compact 2>/dev/null &&
            log_info "Triggered initial ZRAM compaction"
    fi
}

# Get ZRAM statistics
get_zram_stats() {
    if [ ! -e /dev/zram0 ]; then
        log_error "ZRAM device not available"
        return 1
    fi
    
    local orig_data=$(cat /sys/block/zram0/orig_data_size 2>/dev/null || echo 0)
    local compr_data=$(cat /sys/block/zram0/compr_data_size 2>/dev/null || echo 0)
    local mem_used=$(cat /sys/block/zram0/mem_used_total 2>/dev/null || echo 0)
    
    # Convert to MB for readability
    orig_data=$((orig_data / 1024 / 1024))
    compr_data=$((compr_data / 1024 / 1024))
    mem_used=$((mem_used / 1024 / 1024))
    
    # Calculate compression ratio
    local ratio=0
    if [ ${compr_data} -gt 0 ]; then
        ratio=$(echo "scale=2; ${orig_data} / ${compr_data}" | bc 2>/dev/null || echo "N/A")
    fi
    
    echo "ZRAM Statistics:"
    echo "  Original data: ${orig_data} MB"
    echo "  Compressed: ${compr_data} MB"
    echo "  Memory used: ${mem_used} MB"
    echo "  Compression ratio: ${ratio}:1"
    
    return 0
}