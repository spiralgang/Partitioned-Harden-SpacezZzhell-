#!/bin/bash
#================================================================
# ZShell Isolated Android Environment Builder
# Version: 2.0.0
# Target: Samsung Galaxy S9+ (SM-G965U1) / Android 10
# Environment: UserLAnd
#================================================================

set -eo pipefail

#================================================================
# CONFIGURATION
#================================================================
ZSHELL_VERSION="2.0.0"
ZSHELL_ROOT="/data/local/zshell"
USERLAND_ROOT="$HOME"
FIRMWARE_URL=""
TEMP_DIR="/tmp/zshell_build"
LOG_FILE="${TEMP_DIR}/zshell_build.log"
ZRAM_SIZE_MB=2048
SSH_PORT=2022

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

#================================================================
# HELPER FUNCTIONS
#================================================================

log() {
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo -e "${BLUE}[${timestamp}]${NC} $1" | tee -a "${LOG_FILE}"
}

log_success() {
    log "${GREEN}[SUCCESS]${NC} $1"
}

log_error() {
    log "${RED}[ERROR]${NC} $1"
}

log_warn() {
    log "${YELLOW}[WARNING]${NC} $1"
}

# Check if command exists
cmd_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Create directory if it doesn't exist
ensure_dir() {
    if [ ! -d "$1" ]; then
        mkdir -p "$1"
    fi
}

# Check if file exists
ensure_file() {
    if [ ! -f "$1" ]; then
        log_error "Required file not found: $1"
        return 1
    fi
}

# Download file with progress
download_file() {
    local url="$1"
    local output="$2"
    
    if cmd_exists wget; then
        wget -O "$output" "$url" || return 1
    elif cmd_exists curl; then
        curl -L -o "$output" "$url" || return 1
    else
        log_error "Neither wget nor curl is available. Cannot download."
        return 1
    fi
}

# Extract firmware file
extract_firmware() {
    local firmware="$1"
    local output_dir="$2"
    
    log "Extracting firmware: $(basename "$firmware")"
    
    # Create output directory
    ensure_dir "$output_dir"
    
    # Try extracting system.img directly
    if unzip -l "$firmware" | grep -q "system.img"; then
        log "Found system.img in firmware, extracting..."
        unzip -j "$firmware" "system.img" -d "$output_dir"
    elif unzip -l "$firmware" | grep -q "system.img.lz4"; then
        log "Found system.img.lz4 in firmware, extracting..."
        unzip -j "$firmware" "system.img.lz4" -d "$output_dir"
        
        # Check if lz4 command exists
        if ! cmd_exists lz4; then
            log "Installing lz4..."
            apt-get update && apt-get install -y lz4 || {
                log_error "Failed to install lz4"
                return 1
            }
        fi
        
        # Decompress system.img.lz4
        log "Decompressing system.img.lz4..."
        lz4 -d "$output_dir/system.img.lz4" "$output_dir/system.img" || {
            log_error "Failed to decompress system.img.lz4"
            return 1
        }
        
        # Remove compressed file
        rm -f "$output_dir/system.img.lz4"
    elif unzip -l "$firmware" | grep -q "AP.*tar.md5"; then
        log "Found AP*.tar.md5 in firmware, extracting..."
        
        # Create temporary directory for extraction
        local ap_dir="${output_dir}/ap_temp"
        ensure_dir "$ap_dir"
        
        # Extract AP*.tar.md5
        unzip -j "$firmware" "AP*.tar.md5" -d "$ap_dir" || {
            log_error "Failed to extract AP*.tar.md5"
            return 1
        }
        
        # Find the AP tar file
        local ap_tar=$(find "$ap_dir" -name "AP*.tar.md5" | head -n 1)
        if [ -z "$ap_tar" ]; then
            log_error "AP*.tar.md5 not found in extracted files"
            return 1
        }
        
        log "Extracting system image from $ap_tar..."
        tar -xf "$ap_tar" -C "$ap_dir" "system.img*" || {
            log_error "Failed to extract system.img from AP*.tar.md5"
            return 1
        }
        
        # Handle lz4 compressed system.img if exists
        if [ -f "$ap_dir/system.img.lz4" ]; then
            log "Decompressing system.img.lz4..."
            lz4 -d "$ap_dir/system.img.lz4" "$output_dir/system.img" || {
                log_error "Failed to decompress system.img.lz4"
                return 1
            }
        elif [ -f "$ap_dir/system.img" ]; then
            log "Moving system.img to output directory..."
            mv "$ap_dir/system.img" "$output_dir/"
        else
            log_error "system.img not found in extracted AP*.tar.md5"
            return 1
        }
        
        # Clean up temporary directory
        rm -rf "$ap_dir"
    else
        log_error "Could not find system.img, system.img.lz4, or AP*.tar.md5 in firmware"
        return 1
    fi
    
    # Verify system.img exists
    if [ ! -f "$output_dir/system.img" ]; then
        log_error "system.img not found after extraction"
        return 1
    fi
    
    # Check if we need to convert sparse image
    if file "$output_dir/system.img" | grep -q "Android sparse image"; then
        log "Converting sparse system.img to raw format..."
        
        # Check if simg2img command exists
        if ! cmd_exists simg2img; then
            log "Installing simg2img..."
            apt-get update && apt-get install -y android-tools-fsutils || {
                log_error "Failed to install simg2img"
                return 1
            }
        }
        
        # Convert sparse image to raw
        simg2img "$output_dir/system.img" "$output_dir/system.img.raw" || {
            log_error "Failed to convert sparse image"
            return 1
        }
        
        # Replace sparse image with raw image
        mv "$output_dir/system.img.raw" "$output_dir/system.img"
    fi
    
    log_success "System image extracted successfully"
    return 0
}

# Check dependencies
check_dependencies() {
    local missing_deps=()
    
    log "Checking dependencies..."
    
    # Required packages
    local deps=(
        "unzip"
        "wget" 
        "curl"
        "lz4"
        "proot"
        "util-linux"
        "openssh-client"
        "tar"
        "mount"
        "jq"
    )
    
    for dep in "${deps[@]}"; do
        if ! cmd_exists "$dep"; then
            missing_deps+=("$dep")
        fi
    done
    
    if [ ${#missing_deps[@]} -gt 0 ]; then
        log "Installing missing dependencies: ${missing_deps[*]}"
        apt-get update || {
            log_error "Failed to update package lists"
            return 1
        }
        
        apt-get install -y "${missing_deps[@]}" || {
            log_error "Failed to install dependencies"
            return 1
        }
    fi
    
    # Check for special dependencies
    if ! cmd_exists simg2img; then
        log "Installing simg2img..."
        apt-get install -y android-tools-fsutils || {
            # Try alternative package
            apt-get install -y android-sdk-libsparse-utils || {
                log_warn "Could not install simg2img. May be needed for sparse images."
            }
        }
    fi
    
    log_success "All dependencies satisfied"
    return 0
}

# Create SSH keys
setup_ssh() {
    local ssh_dir="$1"
    
    log "Setting up SSH..."
    
    # Create SSH directory
    ensure_dir "$ssh_dir"
    
    # Generate host key if it doesn't exist
    if [ ! -f "${ssh_dir}/ssh_host_ed25519_key" ]; then
        log "Generating SSH host key..."
        ssh-keygen -t ed25519 -f "${ssh_dir}/ssh_host_ed25519_key" -N "" || {
            log_error "Failed to generate SSH host key"
            return 1
        }
    fi
    
    # Generate user key if it doesn't exist
    if [ ! -f "${ssh_dir}/id_ed25519" ]; then
        log "Generating user SSH key pair..."
        ssh-keygen -t ed25519 -f "${ssh_dir}/id_ed25519" -N "" || {
            log_error "Failed to generate user SSH key"
            return 1
        }
    fi
    
    # Set up authorized_keys
    if [ -f "${ssh_dir}/id_ed25519.pub" ]; then
        cat "${ssh_dir}/id_ed25519.pub" > "${ssh_dir}/authorized_keys"
        chmod 600 "${ssh_dir}/authorized_keys"
    fi
    
    # Create SSH config
    cat > "${ssh_dir}/sshd_config" << EOF
# ZShell SSH Server Configuration
Port ${SSH_PORT}
HostKey ${ssh_dir}/ssh_host_ed25519_key
AuthorizedKeysFile ${ssh_dir}/authorized_keys
PermitRootLogin yes
PasswordAuthentication no
PermitEmptyPasswords no
ChallengeResponseAuthentication no
UsePAM no
X11Forwarding no
PrintMotd no
AcceptEnv LANG LC_*
Subsystem sftp internal-sftp
EOF
    
    log_success "SSH setup complete"
    return 0
}

# Set up ZRAM configuration
setup_zram() {
    local config_dir="$1"
    local size_mb="$2"
    
    log "Setting up ZRAM configuration (${size_mb}MB)..."
    
    # Create ZRAM configuration directory
    ensure_dir "${config_dir}/zram"
    
    # Create ZRAM configuration file
    cat > "${config_dir}/zram/zram_config.sh" << EOF
#!/bin/bash
# ZRAM Configuration for ZShell

# Set ZRAM size
ZRAM_SIZE_MB=${size_mb}
ZRAM_ALGORITHM="lz4"
ZRAM_STREAMS=$(nproc)
ZRAM_PRIORITY=100

# Initialize ZRAM
setup_zram() {
    # Check if ZRAM module is available
    if ! grep -q zram /proc/modules 2>/dev/null; then
        modprobe zram num_devices=1 || {
            echo "Failed to load ZRAM module"
            return 1
        }
    fi
    
    # Reset any existing ZRAM config
    if [ -e /dev/zram0 ]; then
        if grep -q /dev/zram0 /proc/swaps 2>/dev/null; then
            swapoff /dev/zram0 || echo "Failed to deactivate existing ZRAM"
        fi
        echo 1 > /sys/block/zram0/reset 2>/dev/null || echo "Failed to reset ZRAM device"
    fi
    
    # Configure ZRAM
    echo "\${ZRAM_ALGORITHM}" > /sys/block/zram0/comp_algorithm 2>/dev/null || true
    echo "\${ZRAM_STREAMS}" > /sys/block/zram0/max_comp_streams 2>/dev/null || true
    echo \$((\${ZRAM_SIZE_MB}*1024*1024)) > /sys/block/zram0/disksize || {
        echo "Failed to set ZRAM size"
        return 1
    }
    
    # Enable Samsung-specific optimizations
    if [ -f "/sys/block/zram0/use_dedup" ]; then
        echo "1" > /sys/block/zram0/use_dedup 2>/dev/null && \
            echo "Enabled memory deduplication"
    fi
    
    # Initialize swap
    mkswap /dev/zram0 >/dev/null || {
        echo "Failed to format ZRAM device"
        return 1
    }
    
    # Activate swap
    swapon -p \${ZRAM_PRIORITY} /dev/zram0 || {
        echo "Failed to activate ZRAM swap"
        return 1
    }
    
    echo "ZRAM initialized: \${ZRAM_SIZE_MB}MB with \${ZRAM_ALGORITHM} compression"
    return 0
}

# Get ZRAM statistics
get_zram_stats() {
    if [ ! -e /dev/zram0 ]; then
        echo "ZRAM device not available"
        return 1
    fi
    
    local orig_data=\$(cat /sys/block/zram0/orig_data_size 2>/dev/null || echo 0)
    local compr_data=\$(cat /sys/block/zram0/compr_data_size 2>/dev/null || echo 0)
    local mem_used=\$(cat /sys/block/zram0/mem_used_total 2>/dev/null || echo 0)
    
    # Convert to MB for readability
    orig_data=\$((\$orig_data / 1024 / 1024))
    compr_data=\$((\$compr_data / 1024 / 1024))
    mem_used=\$((\$mem_used / 1024 / 1024))
    
    # Calculate compression ratio
    if [ \${compr_data} -gt 0 ]; then
        ratio=\$(echo "scale=2; \${orig_data} / \${compr_data}" | bc 2>/dev/null || echo "N/A")
    else
        ratio="N/A"
    fi
    
    echo "ZRAM Statistics:"
    echo "  Original data: \${orig_data} MB"
    echo "  Compressed: \${compr_data} MB"
    echo "  Memory used: \${mem_used} MB"
    echo "  Compression ratio: \${ratio}:1"
}

# Run setup
if [ "\$1" = "stats" ]; then
    get_zram_stats
else
    setup_zram
fi
EOF
    
    # Make script executable
    chmod +x "${config_dir}/zram/zram_config.sh"
    
    log_success "ZRAM configuration complete"
    return 0
}

# Set up namespace isolation
setup_namespaces() {
    local config_dir="$1"
    
    log "Setting up namespace isolation..."
    
    # Create namespace directory
    ensure_dir "${config_dir}/ns"
    
    # Create namespace initialization script
    cat > "${config_dir}/ns/init_namespaces.sh" << EOF
#!/bin/bash
# Namespace Initialization for ZShell

# Create isolated namespaces
create_namespaces() {
    echo "Creating isolated namespaces..."
    
    # Use unshare to create new namespaces
    unshare --mount --uts --ipc --pid --fork --mount-proc /bin/bash -c "
        # Set hostname
        hostname zshell
        
        # Mount essential filesystems
        mount -t proc proc /proc || echo 'Failed to mount /proc'
        mount -t sysfs sys /sys || echo 'Failed to mount /sys'
        
        # Execute command
        exec \$@
    " "\$@"
}

# Start with namespace isolation
if [ \$# -eq 0 ]; then
    echo "Usage: \$0 COMMAND [ARGS]"
    exit 1
fi

create_namespaces "\$@"
EOF
    
    # Make script executable
    chmod +x "${config_dir}/ns/init_namespaces.sh"
    
    log_success "Namespace isolation setup complete"
    return 0
}

# Setup filesystem overlay
setup_overlay() {
    local config_dir="$1"
    local system_img="$2"
    
    log "Setting up overlay filesystem..."
    
    # Create overlay directories
    ensure_dir "${config_dir}/rootfs"
    ensure_dir "${config_dir}/system_ro"
    ensure_dir "${config_dir}/overlay"
    ensure_dir "${config_dir}/work"
    
    # Create overlay mount script
    cat > "${config_dir}/mount_overlay.sh" << EOF
#!/bin/bash
# Overlay Filesystem Mount Script

ZSHELL_ROOT="$config_dir"
SYSTEM_IMG="\${ZSHELL_ROOT}/system.img"
MOUNT_RO="\${ZSHELL_ROOT}/system_ro"
MOUNT_OVERLAY="\${ZSHELL_ROOT}/overlay"
MOUNT_WORK="\${ZSHELL_ROOT}/work"
MOUNT_ROOT="\${ZSHELL_ROOT}/rootfs"

# Check if system image exists
if [ ! -f "\${SYSTEM_IMG}" ]; then
    echo "Error: System image not found at \${SYSTEM_IMG}"
    exit 1
fi

# Mount the read-only layer if not already mounted
if ! mountpoint -q "\${MOUNT_RO}"; then
    echo "Mounting system image as read-only..."
    mount -o loop,ro "\${SYSTEM_IMG}" "\${MOUNT_RO}" || {
        echo "Failed to mount system image"
        exit 1
    }
    echo "System image mounted at \${MOUNT_RO}"
fi

# Mount the overlay if not already mounted
if ! mountpoint -q "\${MOUNT_ROOT}"; then
    echo "Creating overlay filesystem..."
    mount -t overlay overlay \
        -o lowerdir="\${MOUNT_RO}",upperdir="\${MOUNT_OVERLAY}",workdir="\${MOUNT_WORK}" \
        "\${MOUNT_ROOT}" || {
        echo "Failed to create overlay mount"
        umount "\${MOUNT_RO}" 2>/dev/null
        exit 1
    }
    echo "Overlay filesystem mounted at \${MOUNT_ROOT}"
fi

# Mount special filesystems
for dir in proc sys dev; do
    mkdir -p "\${MOUNT_ROOT}/\${dir}"
    if [ "\${dir}" = "dev" ]; then
        mount -o bind /dev "\${MOUNT_ROOT}/dev" || echo "Warning: Failed to bind mount /dev"
    elif [ "\${dir}" = "proc" ]; then
        mount -t proc proc "\${MOUNT_ROOT}/proc" || echo "Warning: Failed to mount /proc"
    elif [ "\${dir}" = "sys" ]; then
        mount -t sysfs sys "\${MOUNT_ROOT}/sys" || echo "Warning: Failed to mount /sys"
    fi
done

echo "Overlay filesystem setup complete"
EOF
    
    # Create unmount script
    cat > "${config_dir}/umount_overlay.sh" << EOF
#!/bin/bash
# Overlay Filesystem Unmount Script

ZSHELL_ROOT="$config_dir"
MOUNT_ROOT="\${ZSHELL_ROOT}/rootfs"
MOUNT_RO="\${ZSHELL_ROOT}/system_ro"

# Unmount special filesystems
for dir in proc sys dev; do
    umount "\${MOUNT_ROOT}/\${dir}" 2>/dev/null
done

# Unmount overlay
if mountpoint -q "\${MOUNT_ROOT}"; then
    echo "Unmounting overlay filesystem..."
    umount "\${MOUNT_ROOT}" || {
        echo "Warning: Failed to unmount overlay cleanly"
        echo "Trying lazy unmount..."
        umount -l "\${MOUNT_ROOT}"
    }
fi

# Unmount read-only layer
if mountpoint -q "\${MOUNT_RO}"; then
    echo "Unmounting system image..."
    umount "\${MOUNT_RO}" || {
        echo "Warning: Failed to unmount system image cleanly"
        echo "Trying lazy unmount..."
        umount -l "\${MOUNT_RO}"
    }
fi

echo "Overlay filesystem unmounted"
EOF
    
    # Make scripts executable
    chmod +x "${config_dir}/mount_overlay.sh"
    chmod +x "${config_dir}/umount_overlay.sh"
    
    # Copy system image if provided
    if [ -n "$system_img" ] && [ -f "$system_img" ]; then
        log "Copying system image to ${config_dir}/system.img..."
        cp "$system_img" "${config_dir}/system.img" || {
            log_error "Failed to copy system image"
            return 1
        }
    fi
    
    log_success "Overlay filesystem setup complete"
    return 0
}

# Create main launcher script
create_launcher() {
    local config_dir="$1"
    
    log "Creating launcher script..."
    
    # Create main launcher script
    cat > "${config_dir}/zshell.sh" << EOF
#!/bin/bash
# ZShell - Android Isolated Environment Launcher
# Version: ${ZSHELL_VERSION}

ZSHELL_ROOT="$config_dir"
SSH_PORT=${SSH_PORT}

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print banner
print_banner() {
    echo -e "\${BLUE}┌───────────────────────────────────────────────────────┐"
    echo -e "│               ZShell Isolated Environment              │"
    echo -e "├───────────────────────────────────────────────────────┤"
    echo -e "│                                                       │"
    echo -e "│  ┌─────────┐    ┌──────────┐    ┌──────────────┐      │"
    echo -e "│  │ Isolated │    │   ZRAM   │    │   UserLAnd   │      │"
    echo -e "│  │ Android  │◄───┤Optimizer │◄───┤ Integration  │      │"
    echo -e "│  └─────────┘    └──────────┘    └──────────────┘      │"
    echo -e "│      │               │                │               │"
    echo -e "│      ▼               ▼                ▼               │"
    echo -e "│  ┌─────────┐    ┌──────────┐    ┌──────────────┐      │"
    echo -e "│  │ Overlay  │    │ Namespace │    │     SSH     │      │"
    echo -e "│  │ Filesys  │    │ Isolation │    │    Tunnel   │      │"
    echo -e "│  └─────────┘    └──────────┘    └──────────────┘      │"
    echo -e "│                                                       │"
    echo -e "└───────────────────────────────────────────────────────┘\${NC}"
    echo -e "               Version ${ZSHELL_VERSION} - SM-G965U1/Android 10\n"
}

# Check requirements
check_requirements() {
    # Check if system image exists
    if [ ! -f "\${ZSHELL_ROOT}/system.img" ]; then
        echo -e "\${RED}Error: System image not found at \${ZSHELL_ROOT}/system.img\${NC}"
        echo "Please run the setup script first."
        return 1
    fi
    return 0
}

# Start ZShell environment
start_zshell() {
    print_banner
    
    # Check requirements
    check_requirements || return 1
    
    echo -e "\${BLUE}Starting ZShell isolated environment...\${NC}"
    
    # Mount overlay filesystem
    echo "Mounting overlay filesystem..."
    "\${ZSHELL_ROOT}/mount_overlay.sh" || {
        echo -e "\${RED}Failed to mount overlay filesystem\${NC}"
        return 1
    }
    
    # Set up ZRAM
    echo "Initializing ZRAM..."
    "\${ZSHELL_ROOT}/zram/zram_config.sh" || {
        echo -e "\${YELLOW}Warning: Failed to initialize ZRAM\${NC}"
        # Continue anyway
    }
    
    # Start SSH server
    if [ -d "\${ZSHELL_ROOT}/ssh" ] && [ -f "\${ZSHELL_ROOT}/ssh/ssh_host_ed25519_key" ]; then
        echo "Starting SSH server on port \${SSH_PORT}..."
        
        # Check if dropbear is available, otherwise use OpenSSH
        if command -v dropbear >/dev/null 2>&1; then
            dropbear -r "\${ZSHELL_ROOT}/ssh/ssh_host_ed25519_key" -p "\${SSH_PORT}" -F -E -P "\${ZSHELL_ROOT}/ssh/dropbear.pid" || {
                echo -e "\${YELLOW}Warning: Failed to start Dropbear SSH server\${NC}"
            }
        elif command -v sshd >/dev/null 2>&1; then
            sshd -f "\${ZSHELL_ROOT}/ssh/sshd_config" || {
                echo -e "\${YELLOW}Warning: Failed to start OpenSSH server\${NC}"
            }
        else
            echo -e "\${YELLOW}Warning: No SSH server available\${NC}"
        fi
    else
        echo -e "\${YELLOW}Warning: SSH keys not found, SSH server not started\${NC}"
    fi
    
    # Enter the environment
    echo -e "\${GREEN}ZShell environment ready!\${NC}"
    echo "Entering isolated environment..."
    
    # Use proot-distro for UserLAnd integration
    if command -v proot-distro >/dev/null 2>&1; then
        # We're likely in UserLAnd
        proot -r "\${ZSHELL_ROOT}/rootfs" \
            -b /dev \
            -b /proc \
            -b /sys \
            -w / \
            /system/bin/sh
    else
        # Fallback to direct proot
        proot -r "\${ZSHELL_ROOT}/rootfs" \
            -b /dev \
            -b /proc \
            -b /sys \
            -w / \
            /system/bin/sh
    fi
    
    # Clean up on exit
    echo "Exiting ZShell environment..."
    stop_zshell
}

# Stop ZShell environment
stop_zshell() {
    echo -e "\${BLUE}Stopping ZShell environment...\${NC}"
    
    # Stop SSH server
    if [ -f "\${ZSHELL_ROOT}/ssh/dropbear.pid" ]; then
        echo "Stopping SSH server..."
        kill \$(cat "\${ZSHELL_ROOT}/ssh/dropbear.pid") 2>/dev/null || true
        rm -f "\${ZSHELL_ROOT}/ssh/dropbear.pid"
    fi
    
    # Disable ZRAM
    if grep -q /dev/zram0 /proc/swaps 2>/dev/null; then
        echo "Deactivating ZRAM..."
        swapoff /dev/zram0 2>/dev/null || true
    fi
    
    # Unmount overlay filesystem
    echo "Unmounting filesystems..."
    "\${ZSHELL_ROOT}/umount_overlay.sh"
    
    echo -e "\${GREEN}ZShell environment stopped\${NC}"
}

# Show status
show_status() {
    print_banner
    
    echo -e "\${BLUE}ZShell Status\${NC}"
    echo "---------------"
    
    # Check if overlay is mounted
    if mountpoint -q "\${ZSHELL_ROOT}/rootfs"; then
        echo -e "Overlay filesystem: \${GREEN}Mounted\${NC}"
    else
        echo -e "Overlay filesystem: \${RED}Not mounted\${NC}"
    fi
    
    # Check if ZRAM is active
    if grep -q /dev/zram0 /proc/swaps 2>/dev/null; then
        echo -e "ZRAM status: \${GREEN}Active\${NC}"
        echo "ZRAM statistics:"
        "\${ZSHELL_ROOT}/zram/zram_config.sh" stats
    else
        echo -e "ZRAM status: \${RED}Inactive\${NC}"
    fi
    
    # Check SSH server
    if ps aux | grep -v grep | grep -q "dropbear.*\${SSH_PORT}" || \
       ps aux | grep -v grep | grep -q "sshd.*\${SSH_PORT}"; then
        echo -e "SSH server: \${GREEN}Running on port \${SSH_PORT}\${NC}"
        echo "SSH key: \${ZSHELL_ROOT}/ssh/id_ed25519"
        echo "SSH command: ssh -p \${SSH_PORT} -i \${ZSHELL_ROOT}/ssh/id_ed25519 localhost"
    else
        echo -e "SSH server: \${RED}Not running\${NC}"
    fi
}

# Process command
case "\$1" in
    start)
        start_zshell
        ;;
    stop)
        stop_zshell
        ;;
    status)
        show_status
        ;;
    *)
        print_banner
        echo "Usage: \$0 {start|stop|status}"
        echo ""
        echo "Commands:"
        echo "  start   - Start the isolated environment"
        echo "  stop    - Stop the isolated environment"
        echo "  status  - Show environment status"
        ;;
esac

exit 0
EOF
    
    # Make script executable
    chmod +x "${config_dir}/zshell.sh"
    
    log_success "Launcher script created"
    return 0
}

# Setup UserLAnd integration
setup_userland_integration() {
    local config_dir="$1"
    
    log "Setting up UserLAnd integration..."
    
    # Create UserLAnd integration script
    cat > "${USERLAND_ROOT}/zshell_userland_setup.sh" << EOF
#!/bin/bash
# ZShell UserLAnd Integration Script

ZSHELL_ROOT="$config_dir"
USERLAND_ROOT="$USERLAND_ROOT"

# Create shortcut in UserLAnd
ln -sf "\${ZSHELL_ROOT}/zshell.sh" "\${USERLAND_ROOT}/zshell"
chmod +x "\${USERLAND_ROOT}/zshell"

# Create aliases
cat > "\${USERLAND_ROOT}/.zshell_aliases" << 'EOL'
# ZShell aliases
alias zshell="\${HOME}/zshell"
alias zs="\${HOME}/zshell start"
alias zshell-start="\${HOME}/zshell start"
alias zshell-stop="\${HOME}/zshell stop"
alias zshell-status="\${HOME}/zshell status"
EOL

# Add to .bashrc if not already there
if ! grep -q "source.*\.zshell_aliases" "\${USERLAND_ROOT}/.bashrc" 2>/dev/null; then
    echo "" >> "\${USERLAND_ROOT}/.bashrc"
    echo "# ZShell aliases" >> "\${USERLAND_ROOT}/.bashrc"
    echo "if [ -f \"\${HOME}/.zshell_aliases\" ]; then" >> "\${USERLAND_ROOT}/.bashrc"
    echo "    source \"\${HOME}/.zshell_aliases\"" >> "\${USERLAND_ROOT}/.bashrc"
    echo "fi" >> "\${USERLAND_ROOT}/.bashrc"
fi

echo "ZShell integrated with UserLAnd"
echo "You can now use 'zshell', 'zs', or 'zshell-start' to launch ZShell"
EOF
    
    # Make script executable
    chmod +x "${USERLAND_ROOT}/zshell_userland_setup.sh"
    
    # Run the integration script
    bash "${USERLAND_ROOT}/zshell_userland_setup.sh" || {
        log_warn "Failed to run UserLAnd integration script"
        return 1
    }
    
    log_success "UserLAnd integration complete"
    return 0
}

#================================================================
# MAIN SCRIPT
#================================================================

main() {
    local firmware_file=""
    local system_img=""
    
    # Create temporary directory
    ensure_dir "${TEMP_DIR}"
    
    # Initialize log file
    echo "=== ZShell Build Log - $(date) ===" > "${LOG_FILE}"
    log "Starting ZShell build process v${ZSHELL_VERSION}"
    
    # Display banner
    echo -e "${BLUE}┌───────────────────────────────────────────────────────┐"
    echo -e "│               ZShell Isolated Environment              │"
    echo -e "├───────────────────────────────────────────────────────┤"
    echo -e "│                                                       │"
    echo -e "│  ┌─────────┐    ┌──────────┐    ┌──────────────┐      │"
    echo -e "│  │ Isolated │    │   ZRAM   │    │   UserLAnd   │      │"
    echo -e "│  │ Android  │◄───┤Optimizer │◄───┤ Integration  │      │"
    echo -e "│  └─────────┘    └──────────┘    └──────────────┘      │"
    echo -e "│      │               │                │               │"
    echo -e "│      ▼               ▼                ▼               │"
    echo -e "│  ┌─────────┐    ┌──────────┐    ┌──────────────┐      │"
    echo -e "│  │ Overlay  │    │ Namespace │    │     SSH     │      │"
    echo -e "│  │ Filesys  │    │ Isolation │    │    Tunnel   │      │"
    echo -e "│  └─────────┘    └──────────┘    └──────────────┘      │"
    echo -e "│                                                       │"
    echo -e "└───────────────────────────────────────────────────────┘${NC}"
    echo -e "               Version ${ZSHELL_VERSION} - SM-G965U1/Android 10\n"
    
    # Check device compatibility
    local model=$(getprop ro.product.model 2>/dev/null || echo "unknown")
    local android_ver=$(getprop ro.build.version.release 2>/dev/null || echo "unknown")
    
    log "Detected device: ${model}, Android ${android_ver}"
    
    if [ "${model}" != "SM-G965U1" ] && [ "${model}" != "unknown" ]; then
        log_warn "This script is optimized for SM-G965U1, but detected: ${model}"
        log_warn "Some features may not work correctly on this device."
        
        echo -e "${YELLOW}WARNING: This script is optimized for SM-G965U1, but detected: ${model}"
        echo -e "Some features may not work correctly on this device.${NC}"
        read -p "Continue anyway? [y/N] " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            log_error "Installation aborted by user"
            exit 1
        fi
    fi
    
    # Check dependencies
    check_dependencies || {
        log_error "Failed to install required dependencies"
        exit 1
    }
    
    # Create ZShell root directory
    ensure_dir "${ZSHELL_ROOT}"
    
    # Process firmware or system image
    if [ -n "${FIRMWARE_URL}" ]; then
        # Download firmware
        firmware_file="${TEMP_DIR}/firmware.zip"
        log "Downloading firmware from ${FIRMWARE_URL}..."
        download_file "${FIRMWARE_URL}" "${firmware_file}" || {
            log_error "Failed to download firmware"
            exit 1
        }
    else
        # Prompt for firmware path
        echo -e "${BLUE}Firmware/System Image Setup${NC}"
        echo "Please specify one of the following:"
        echo "1. Path to firmware .zip file"
        echo "2. Path to system.img file"
        echo "3. URL to download firmware"
        echo -n "Enter your choice: "
        read choice
        
        case "$choice" in
            1)
                echo -n "Enter path to firmware .zip file: "
                read firmware_path
                
                if [ ! -f "${firmware_path}" ]; then
                    log_error "Firmware file not found: ${firmware_path}"
                    exit 1
                fi
                
                firmware_file="${firmware_path}"
                ;;
            2)
                echo -n "Enter path to system.img file: "
                read simg_path
                
                if [ ! -f "${simg_path}" ]; then
                    log_error "System image file not found: ${simg_path}"
                    exit 1
                }
                
                system_img="${simg_path}"
                ;;
            3)
                echo -n "Enter URL to download firmware: "
                read firmware_url
                
                firmware_file="${TEMP_DIR}/firmware.zip"
                log "Downloading firmware from ${firmware_url}..."
                download_file "${firmware_url}" "${firmware_file}" || {
                    log_error "Failed to download firmware"
                    exit 1
                }
                ;;
            *)
                log_error "Invalid choice"
                exit 1
                ;;
        esac
    fi
    
    # Extract firmware if needed
    if [ -n "${firmware_file}" ] && [ -f "${firmware_file}" ]; then
        extract_firmware "${firmware_file}" "${TEMP_DIR}" || {
            log_error "Failed to extract firmware"
            exit 1
        }
        
        system_img="${TEMP_DIR}/system.img"
    fi
    
    # Set up SSH
    setup_ssh "${ZSHELL_ROOT}/ssh" || {
        log_warn "Failed to set up SSH"
    }
    
    # Set up ZRAM configuration
    setup_zram "${ZSHELL_ROOT}" "${ZRAM_SIZE_MB}" || {
        log_warn "Failed to set up ZRAM configuration"
    }
    
    # Set up namespaces
    setup_namespaces "${ZSHELL_ROOT}" || {
        log_warn "Failed to set up namespace isolation"
    }
    
    # Set up overlay filesystem
    setup_overlay "${ZSHELL_ROOT}" "${system_img}" || {
        log_error "Failed to set up overlay filesystem"
        exit 1
    }
    
    # Create launcher script
    create_launcher "${ZSHELL_ROOT}" || {
        log_error "Failed to create launcher script"
        exit 1
    }
    
    # Set up UserLAnd integration
    setup_userland_integration "${ZSHELL_ROOT}" || {
        log_warn "Failed to set up UserLAnd integration"
    }
    
    # Clean up temporary files
    if [ -d "${TEMP_DIR}" ] && [ "${TEMP_DIR}" != "/" ]; then
        log "Cleaning up temporary files..."
        rm -rf "${TEMP_DIR}/extract" 2>/dev/null || true
        # Keep the log file
    fi
    
    log_success "ZShell build complete!"
    
    echo -e "\n${GREEN}===============================================${NC}"
    echo -e "${GREEN}ZShell isolated environment has been set up successfully!${NC}"
    echo -e "${GREEN}===============================================${NC}"
    echo ""
    echo -e "To start the environment: ${BLUE}zshell start${NC}"
    echo -e "To check status: ${BLUE}zshell status${NC}"
    echo -e "To stop the environment: ${BLUE}zshell stop${NC}"
    echo ""
    echo -e "Installation directory: ${YELLOW}${ZSHELL_ROOT}${NC}"
    echo -e "Log file: ${YELLOW}${LOG_FILE}${NC}"
    echo ""
    echo -e "UserLAnd integration has been set up with aliases:"
    echo -e "  ${BLUE}zshell${NC}, ${BLUE}zs${NC}, ${BLUE}zshell-start${NC}, ${BLUE}zshell-stop${NC}, ${BLUE}zshell-status${NC}"
    echo ""
    echo -e "${GREEN}Enjoy your isolated Android environment!${NC}"
}

# Run main function
main "$@"