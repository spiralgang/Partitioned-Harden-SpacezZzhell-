#!/system/bin/sh
# System Image Extractor
# Extracts and processes Android system images from Samsung firmware

HAIF_ROOT="/data/local/hardened_android"
FIRMWARE_DIR="${HAIF_ROOT}/firmware"
OUTPUT_DIR="${HAIF_ROOT}/system"

source "${HAIF_ROOT}/lib/logging.sh"
source "${HAIF_ROOT}/lib/mount_controller.sh"

usage() {
    echo "Usage: $0 [options] FIRMWARE_FILE"
    echo ""
    echo "Options:"
    echo "  -o, --output DIR    Output directory (default: ${OUTPUT_DIR})"
    echo "  -h, --help          Show this help message"
    echo ""
    echo "Example:"
    echo "  $0 SM-G965U1_XAR_G965U1UES9FVD1.zip"
}

extract_samsung_firmware() {
    local firmware_file="$1"
    local output_dir="$2"
    
    log_info "Extracting Samsung firmware: $(basename "${firmware_file}")"
    
    # Create temporary extraction directory
    local extract_dir="${HAIF_ROOT}/tmp/extract_$(date +%s)"
    mkdir -p "${extract_dir}"
    
    # Extract firmware components
    extract_system_image "${firmware_file}" "${output_dir}/system.img" || {
        log_error "Failed to extract system image"
        rm -rf "${extract_dir}"
        return 1
    }
    
    # Extract boot.img if available
    unzip -j "${firmware_file}" "boot.img" -d "${extract_dir}" 2>/dev/null && {
        log_info "Extracted boot.img"
        mkdir -p "${HAIF_ROOT}/kernel"
        mv "${extract_dir}/boot.img" "${HAIF_ROOT}/kernel/"
    }
    
    # Extract vendor.img if available
    unzip -j "${firmware_file}" "vendor.img*" -d "${extract_dir}" 2>/dev/null && {
        log_info "Extracted vendor.img"
        
        # Handle compressed vendor image
        if [ -f "${extract_dir}/vendor.img.lz4" ]; then
            log_info "Decompressing vendor.img.lz4"
            lz4 -d "${extract_dir}/vendor.img.lz4" "${extract_dir}/vendor.img" || log_warn "Failed to decompress vendor.img.lz4"
        fi
        
        if [ -f "${extract_dir}/vendor.img" ]; then
            mkdir -p "${HAIF_ROOT}/vendor"
            mv "${extract_dir}/vendor.img" "${HAIF_ROOT}/vendor/"
        fi
    }
    
    # Clean up extraction directory
    rm -rf "${extract_dir}"
    
    log_info "Firmware extraction complete"
    return 0
}

main() {
    # Parse command line arguments
    local firmware_file=""
    local output_dir="${OUTPUT_DIR}"
    
    while [ $# -gt 0 ]; do
        case "$1" in
            -o|--output)
                output_dir="$2"
                shift 2
                ;;
            -h|--help)
                usage
                exit 0
                ;;
            -*)
                log_error "Unknown option: $1"
                usage
                exit 1
                ;;
            *)
                if [ -z "${firmware_file}" ]; then
                    firmware_file="$1"
                    shift
                else
                    log_error "Unexpected argument: $1"
                    usage
                    exit 1
                fi
                ;;
        esac
    done
    
    # Check if firmware file was provided
    if [ -z "${firmware_file}" ]; then
        log_error "No firmware file specified"
        usage
        exit 1
    fi
    
    # Check if firmware file exists
    if [ ! -f "${firmware_file}" ]; then
        log_error "Firmware file not found: ${firmware_file}"
        exit 1
    fi
    
    # Create output directory
    mkdir -p "${output_dir}"
    
    # Extract firmware
    extract_samsung_firmware "${firmware_file}" "${output_dir}" || exit 1
    
    log_info "System image extraction completed successfully"
    return 0
}

main "$@"