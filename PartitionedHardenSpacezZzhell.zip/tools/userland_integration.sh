#!/system/bin/sh
# UserLAnd Integration for HAIF
# Integrates HAIF with UserLAnd for unrooted Android devices

HAIF_ROOT="/data/local/hardened_android"
USERLAND_ROOT="/data/data/tech.ula/files"
USERLAND_ASSETS="${USERLAND_ROOT}/assets"
USERLAND_FS="${USERLAND_ROOT}/filesystems"
DISTRO="ubuntu"
RELEASE="focal"

source "${HAIF_ROOT}/lib/logging.sh"

setup_userland() {
    log_info "Setting up UserLAnd integration..."
    
    # Check if UserLAnd is installed
    if [ ! -d "${USERLAND_ROOT}" ]; then
        log_error "UserLAnd not installed or data directory not accessible"
        return 1
    fi
    
    # Create filesystem configuration
    mkdir -p "${USERLAND_ASSETS}" 2>/dev/null
    
    cat > "${USERLAND_ASSETS}/haif.txt" << EOF
NAME=HardenedAndroid
DISTRIBUTION=${DISTRO}
RELEASE=${RELEASE}
ARCH=arm64
LOCATION=${HAIF_ROOT}
EOF
    
    # Create integration script
    cat > "${USERLAND_ASSETS}/haif_init.sh" << EOF
#!/bin/bash
set -e

# Set up environment variables
export HAIF_ROOT="${HAIF_ROOT}"
export PATH="\${PATH}:\${HAIF_ROOT}/bin"

# Create mountpoint directory
mkdir -p "\${HAIF_ROOT}/userland" 2>/dev/null || true

# Add convenience functions to bashrc
cat > "\${HOME}/.haif_functions" << 'EOL'
haif_start() {
    ${HAIF_ROOT}/bin/haif_launcher start
}

haif_stop() {
    ${HAIF_ROOT}/bin/haif_launcher stop
}

haif_status() {
    ${HAIF_ROOT}/bin/haif_launcher status
}

haif_shell() {
    ${HAIF_ROOT}/bin/haif_launcher shell
}
EOL

# Source the functions in bashrc
if ! grep -q ".haif_functions" "\${HOME}/.bashrc"; then
    echo "source \${HOME}/.haif_functions" >> "\${HOME}/.bashrc"
fi

echo "HAIF integration with UserLAnd complete"
echo "To start HAIF environment, run 'haif_start'"
EOF
    
    chmod +x "${USERLAND_ASSETS}/haif_init.sh"
    
    # Create launcher script
    cat > "${HAIF_ROOT}/bin/haif_launcher" << EOF
#!/system/bin/sh

HAIF_ROOT="${HAIF_ROOT}"
COMMAND="\$1"
ARGS="\${@:2}"

source "\${HAIF_ROOT}/lib/logging.sh"

case "\${COMMAND}" in
    start)
        "\${HAIF_ROOT}/core/framework.sh" start
        ;;
    stop)
        "\${HAIF_ROOT}/core/framework.sh" stop
        ;;
    status)
        if pgrep -f "haif_container" >/dev/null; then
            log_info "HAIF environment is running"
        else
            log_info "HAIF environment is stopped"
        fi
        ;;
    shell)
        if ! pgrep -f "haif_container" >/dev/null; then
            log_error "HAIF environment is not running"
            exit 1
        fi
        "\${HAIF_ROOT}/bin/chisel" exec "haif_container" /system/bin/sh
        ;;
    *)
        echo "Usage: \$0 {start|stop|status|shell}"
        exit 1
        ;;
esac
EOF
    
    chmod +x "${HAIF_ROOT}/bin/haif_launcher"
    
    log_info "UserLAnd integration set up successfully"
    return 0
}

create_launcher_shortcut() {
    log_info "Creating launcher shortcut..."
    
    # Create shortcut script for Android launcher
    local shortcut_dir="/data/local/tmp/shortcuts"
    mkdir -p "${shortcut_dir}" 2>/dev/null
    
    cat > "${shortcut_dir}/launch_haif.sh" << EOF
#!/system/bin/sh
am start -n tech.ula/tech.ula.ui.AppListActivity --es "filesystem" "HardenedAndroid"
EOF
    
    chmod +x "${shortcut_dir}/launch_haif.sh"
    
    log_info "Shortcut created at ${shortcut_dir}/launch_haif.sh"
    return 0
}

main() {
    setup_userland || exit 1
    create_launcher_shortcut || log_warn "Failed to create launcher shortcut"
    
    log_info "UserLAnd integration complete"
    return 0
}

main "$@"