#!/system/bin/sh
# Setup SSH tunnel for isolated Android environment
# Target device: SM-G965U1 (Galaxy S9+), Android 10

set -e

# Configuration
AHIF_ROOT="/data/local/ahif"
SSH_PORT=2022
SSH_KEY_TYPE="ed25519"
SSH_CONFIG="${AHIF_ROOT}/ssh/sshd_config"
SSH_AUTH_KEYS="${AHIF_ROOT}/ssh/authorized_keys"
SSH_HOST_KEY="${AHIF_ROOT}/ssh/host_key"

# Create directory structure
mkdir -p "${AHIF_ROOT}/ssh" "${AHIF_ROOT}/run"

# Log function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# Generate SSH host key if it doesn't exist
if [ ! -f "${SSH_HOST_KEY}" ]; then
    log "Generating SSH host key..."
    ssh-keygen -t "${SSH_KEY_TYPE}" -f "${SSH_HOST_KEY}" -N "" || {
        log "Failed to generate SSH host key"
        exit 1
    }
    log "SSH host key generated"
fi

# Generate user key pair if it doesn't exist
if [ ! -f "${AHIF_ROOT}/ssh/id_${SSH_KEY_TYPE}" ]; then
    log "Generating user SSH key pair..."
    ssh-keygen -t "${SSH_KEY_TYPE}" -f "${AHIF_ROOT}/ssh/id_${SSH_KEY_TYPE}" -N "" || {
        log "Failed to generate user SSH key pair"
        exit 1
    }
    log "User SSH key pair generated"
fi

# Set up authorized_keys
if [ ! -f "${SSH_AUTH_KEYS}" ]; then
    log "Setting up authorized_keys..."
    cat "${AHIF_ROOT}/ssh/id_${SSH_KEY_TYPE}.pub" > "${SSH_AUTH_KEYS}"
    chmod 600 "${SSH_AUTH_KEYS}"
    log "authorized_keys configured"
fi

# Create SSH config
cat > "${SSH_CONFIG}" << EOF
# AHIF SSH Server Configuration
Port ${SSH_PORT}
HostKey ${SSH_HOST_KEY}
AuthorizedKeysFile ${SSH_AUTH_KEYS}
PermitRootLogin prohibit-password
PasswordAuthentication no
PermitEmptyPasswords no
ChallengeResponseAuthentication no
UsePAM no
X11Forwarding no
PrintMotd no
AcceptEnv LANG LC_*
Subsystem sftp internal-sftp
PidFile ${AHIF_ROOT}/run/sshd.pid

# Security settings
AllowAgentForwarding no
AllowTcpForwarding yes
GatewayPorts no
PermitTunnel yes
EOF

# Check if we have dropbear or openssh
if command -v dropbear > /dev/null; then
    log "Using Dropbear SSH server"
    SSHD_CMD="dropbear -r ${SSH_HOST_KEY} -p ${SSH_PORT} -F -E -P ${AHIF_ROOT}/run/dropbear.pid"
elif command -v sshd > /dev/null; then
    log "Using OpenSSH server"
    SSHD_CMD="sshd -f ${SSH_CONFIG}"
else
    log "No SSH server found, installing Dropbear..."
    # Here we would install Dropbear, but in a real implementation
    # this would depend on the specific Android environment
    exit 1
fi

# Start SSH server
log "Starting SSH server on port ${SSH_PORT}..."
${SSHD_CMD} || {
    log "Failed to start SSH server"
    exit 1
}

# Check if SSH server is running
sleep 1
if netstat -ln | grep -q ":${SSH_PORT}"; then
    log "SSH server started successfully on port ${SSH_PORT}"
else
    log "Failed to start SSH server"
    exit 1
fi

log "SSH tunnel setup complete"
log "Connect using: ssh -p ${SSH_PORT} -i ${AHIF_ROOT}/ssh/id_${SSH_KEY_TYPE} root@localhost"

# Copy the private key to a more accessible location for easy retrieval
cp "${AHIF_ROOT}/ssh/id_${SSH_KEY_TYPE}" /sdcard/ahif_ssh_key
chmod 600 /sdcard/ahif_ssh_key
log "Private key copied to /sdcard/ahif_ssh_key for easy retrieval"