#!/bin/bash
# =================================================================
# Samsung ZRAM Optimizer for Isolated Android Environment
# Leverages Samsung-specific ZRAM optimizations for SM-G965U1
# =================================================================
set -euo pipefail

# Samsung ZRAM-specific settings
ZRAM_DIR="/sys/block/zram0"
LOG_FILE="/data/local/tmp/zram_optimizer.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "${LOG_FILE}"
}

check_samsung_zram() {
    if [[ ! -d "${ZRAM_DIR}" ]]; then
        log "ZRAM device not found at ${ZRAM_DIR}"
        return 1
    fi
    
    # Check if this is indeed a Samsung device
    local manufacturer=$(getprop ro.product.manufacturer)
    if [[ "${manufacturer,,}" != *"samsung"* ]]; then
        log "Warning: This doesn't appear to be a Samsung device (${manufacturer})"
        log "Some optimizations may not work correctly."
    fi
    
    return 0
}

optimize_zram() {
    log "Optimizing ZRAM for Samsung device..."
    
    # Get device memory info
    local mem_total=$(cat /proc/meminfo | grep MemTotal | awk '{print $2}')
    local mem_total_mb=$((mem_total / 1024))
    local optimal_zram_size=$((mem_total_mb / 2))
    
    log "Total memory: ${mem_total_mb}MB, Setting ZRAM to ${optimal_zram_size}MB"
    
    # Apply Samsung-specific optimizations
    if [[ -f "${ZRAM_DIR}/use_dedup" ]]; then
        echo "1" > "${ZRAM_DIR}/use_dedup"
        log "Enabled Samsung memory deduplication"
    fi
    
    if [[ -f "${ZRAM_DIR}/comp_algorithm" ]]; then
        echo "lz4" > "${ZRAM_DIR}/comp_algorithm"
        log "Set compression algorithm to Samsung-optimized LZ4"
    fi
    
    if [[ -f "${ZRAM_DIR}/max_comp_streams" ]]; then
        local cpu_count=$(nproc)
        echo "${cpu_count}" > "${ZRAM_DIR}/max_comp_streams"
        log "Set compression streams to ${cpu_count} (matches CPU count)"
    fi
    
    # Set ZRAM size
    if [[ -f "${ZRAM_DIR}/disksize" ]]; then
        echo "$((optimal_zram_size * 1024 * 1024))" > "${ZRAM_DIR}/disksize"
        log "Set ZRAM disk size to ${optimal_zram_size}MB"
    fi
    
    # Trigger manual compaction for efficiency
    if [[ -f "${ZRAM_DIR}/compact" ]]; then
        echo "1" > "${ZRAM_DIR}/compact"
        log "Triggered manual ZRAM compaction"
    fi
    
    log "ZRAM optimization completed"
}

monitor_zram_performance() {
    log "Monitoring ZRAM performance..."
    
    # Show current ZRAM statistics
    local orig_data=$(cat "${ZRAM_DIR}/orig_data_size" 2>/dev/null || echo "0")
    local compr_data=$(cat "${ZRAM_DIR}/compr_data_size" 2>/dev/null || echo "0")
    local mem_used=$(cat "${ZRAM_DIR}/mem_used_total" 2>/dev/null || echo "0")
    
    orig_data=$((orig_data / 1024 / 1024))
    compr_data=$((compr_data / 1024 / 1024))
    mem_used=$((mem_used / 1024 / 1024))
    
    local compression_ratio=0
    if [[ ${orig_data} -gt 0 && ${compr_data} -gt 0 ]]; then
        compression_ratio=$(echo "scale=2; ${orig_data} / ${compr_data}" | bc)
    fi
    
    log "ZRAM Statistics:"
    log "  Original data size: ${orig_data} MB"
    log "  Compressed data size: ${compr_data} MB"
    log "  Memory used: ${mem_used} MB"
    log "  Compression ratio: ${compression_ratio}:1"
    
    # Store statistics for trending
    echo "$(date +%s),${orig_data},${compr_data},${mem_used},${compression_ratio}" >> \
        "/data/local/tmp/zram_stats.csv"
}

main() {
    mkdir -p "$(dirname "${LOG_FILE}")"
    touch "${LOG_FILE}"
    
    log "Starting Samsung ZRAM Optimizer..."
    
    check_samsung_zram || {
        log "ZRAM check failed. Exiting."
        exit 1
    }
    
    optimize_zram
    monitor_zram_performance
    
    log "Samsung ZRAM Optimizer completed successfully."
}

main "$@"