#!/bin/bash
# =================================================================
# UserLAnd Integration Manager for Isolated Android Environment
# Manages the integration between UserLAnd and the isolated Android
# environment for SM-G965U1 using Chisel and ZRAM
# =================================================================
set -euo pipefail

CELL_BASE="/data/local/tmp/android10_isolated"
LOG_FILE="/data/local/tmp/userland_integration.log"
USERLAND_PACKAGE="tech.ula"
DISTRO="ubuntu"
RELEASE="focal"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "${LOG_FILE}"
}

check_userland_installed() {
    log "Checking if UserLAnd is installed..."
    
    if command -v am > /dev/null 2>&1; then
        # Check if UserLAnd is installed
        local result=$(am start -a android.intent.action.VIEW \
            -d "userland://" 2>&1 || echo "not installed")
        
        if [[ "$result" == *"not installed"* || "$result" == *"Error"* ]]; then
            log "UserLAnd not installed or accessible. Please install from Google Play Store."
            return 1
        else
            log "UserLAnd is installed."
            return 0
        fi
    else
        log "Cannot check if UserLAnd is installed: 'am' command not available."
        log "Assuming UserLAnd is installed and continuing..."
        return 0
    fi
}

setup_userland_filesystem() {
    log "Setting up UserLAnd filesystem integration..."
    
    local userland_root="/data/data/${USERLAND_PACKAGE}/files"
    local userland_assets="${userland_root}/assets"
    local userland_support="${userland_root}/support"
    
    # Create directories if they don't exist
    mkdir -p "${userland_assets}" "${userland_support}" 2>/dev/null || true
    
    # Create filesystem configuration
    cat > "${userland_support}/isolated_android.txt" << EOF
NAME=IsolatedAndroid
DISTRIBUTION=${DISTRO}
RELEASE=${RELEASE}
ARCH=arm64
LOCATION=${CELL_BASE}
EOF
    
    # Create filesystem setup script
    cat > "${userland_support}/isolated_android_setup.sh" << EOF
#!/bin/bash
set -e

CELL_BASE="${CELL_BASE}"
SCRIPT_PATH="\$0"

echo "Setting up Isolated Android Environment in UserLAnd..."

# Check if the cell base exists
if [ ! -d "\${CELL_BASE}" ]; then
    echo "Error: Cell base directory \${CELL_BASE} not found!"
    echo "Please run the main setup script first."
    exit 1
fi

# Copy entry script to UserLAnd accessible location
cp "\${CELL_BASE}/enter_isolated_android.sh" "\${HOME}/enter_isolated_android.sh"
chmod +x "\${HOME}/enter_isolated_android.sh"

# Create launch script
cat > "\${HOME}/launch_isolated_android.sh" << 'EOL'
#!/bin/bash
echo "Launching Isolated Android Environment..."
\${HOME}/enter_isolated_android.sh
EOL
chmod +x "\${HOME}/launch_isolated_android.sh"

echo "UserLAnd integration complete!"
echo "To enter the isolated environment, run: \${HOME}/launch_isolated_android.sh"
EOF
    
    chmod +x "${userland_support}/isolated_android_setup.sh"
    
    log "UserLAnd filesystem integration setup complete."
}

configure_userland_distro() {
    log "Configuring UserLAnd distribution..."
    
    # Check if proot-distro is available
    if ! command -v proot-distro > /dev/null 2>&1; then
        log "proot-distro command not available. Skipping distribution configuration."
        return 0
    fi
    
    # Configure the distribution
    proot-distro install "${DISTRO}" || {
        log "Failed to install ${DISTRO} distribution. Please install manually."
        return 1
    }
    
    # Create configuration script
    local config_script="/data/data/${USERLAND_PACKAGE}/files/${DISTRO}/root/configure_isolated.sh"
    
    cat > "${config_script}" << EOF
#!/bin/bash
set -e

# Install dependencies
apt update
apt install -y unzip wget curl p7zip-full simg2img proot util-linux lz4 jq

# Create symbolic links to the isolated environment
ln -sf "${CELL_BASE}" /isolated_android

# Create convenience aliases
cat >> /root/.bashrc << 'EOL'

# Isolated Android Environment aliases
alias isolated='${CELL_BASE}/enter_isolated_android.sh'
alias isolated-status='mountpoint -q "${CELL_BASE}/rootfs" && echo "Isolated environment is mounted" || echo "Isolated environment is not mounted"'
EOL

echo "UserLAnd distribution configuration complete!"
EOF
    
    chmod +x "${config_script}"
    
    # Execute the configuration script
    proot-distro login "${DISTRO}" -- bash /root/configure_isolated.sh || {
        log "Failed to execute configuration script. Please run manually."
        return 1
    }
    
    log "UserLAnd distribution configured successfully."
}

create_userland_launcher() {
    log "Creating UserLAnd launcher..."
    
    local launcher_script="/data/local/bin/launch_isolated_android"
    
    mkdir -p "$(dirname "${launcher_script}")" 2>/dev/null || true
    
    cat > "${launcher_script}" << EOF
#!/system/bin/sh
# UserLAnd launcher for Isolated Android Environment

am start -n "${USERLAND_PACKAGE}/tech.ula.ui.SessionListActivity" --es "filesystem" "IsolatedAndroid" || {
    echo "Failed to launch UserLAnd."
    exit 1
}

echo "UserLAnd launched with Isolated Android Environment."
EOF
    
    chmod +x "${launcher_script}"
    
    log "UserLAnd launcher created at ${launcher_script}."
}

main() {
    mkdir -p "$(dirname "${LOG_FILE}")"
    touch "${LOG_FILE}"
    
    log "Starting UserLAnd Integration Manager..."
    
    check_userland_installed || {
        log "UserLAnd check failed. Please install UserLAnd from the Google Play Store."
        exit 1
    }
    
    setup_userland_filesystem || {
        log "UserLAnd filesystem setup failed."
        exit 1
    }
    
    configure_userland_distro || {
        log "UserLAnd distribution configuration failed."
        exit 1
    }
    
    create_userland_launcher
    
    log "UserLAnd Integration Manager completed successfully."
    log "You can now launch the isolated environment through UserLAnd."
}

main "$@"