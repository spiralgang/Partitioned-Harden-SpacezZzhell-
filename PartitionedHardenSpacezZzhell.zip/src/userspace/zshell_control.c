/**
 * ZShell Control Utility
 * 
 * Provides userspace interface to manage the ZShell isolation framework
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include "../include/zshell_common.h"

#define ZSHELL_DEVICE "/dev/zshell"
#define CONFIG_DIR "/data/local/zshell"

#define COLOR_RED     "\x1b[31m"
#define COLOR_GREEN   "\x1b[32m"
#define COLOR_YELLOW  "\x1b[33m"
#define COLOR_BLUE    "\x1b[34m"
#define COLOR_RESET   "\x1b[0m"

/* IOCTL commands */
#define ZSHELL_IOC_MAGIC 'Z'
#define ZSHELL_IOCTL_START   _IOW(ZSHELL_IOC_MAGIC, 1, struct zshell_start_params)
#define ZSHELL_IOCTL_STOP    _IO(ZSHELL_IOC_MAGIC, 2)
#define ZSHELL_IOCTL_STATUS  _IOR(ZSHELL_IOC_MAGIC, 3, struct zshell_status)
#define ZSHELL_IOCTL_SHELL   _IO(ZSHELL_IOC_MAGIC, 4)
#define ZSHELL_IOCTL_ZRAM_OPT _IOW(ZSHELL_IOC_MAGIC, 5, int)

/* Command handlers */
static int cmd_start(int argc, char *argv[]);
static int cmd_stop(int argc, char *argv[]);
static int cmd_status(int argc, char *argv[]);
static int cmd_shell(int argc, char *argv[]);
static int cmd_optimize(int argc, char *argv[]);
static int cmd_setup(int argc, char *argv[]);
static void show_usage(const char *prog_name);

int main(int argc, char *argv[])
{
    if (argc < 2) {
        show_usage(argv[0]);
        return 1;
    }
    
    /* Process command */
    if (strcmp(argv[1], "start") == 0) {
        return cmd_start(argc - 1, argv + 1);
    } else if (strcmp(argv[1], "stop") == 0) {
        return cmd_stop(argc - 1, argv + 1);
    } else if (strcmp(argv[1], "status") == 0) {
        return cmd_status(argc - 1, argv + 1);
    } else if (strcmp(argv[1], "shell") == 0) {
        return cmd_shell(argc - 1, argv + 1);
    } else if (strcmp(argv[1], "optimize") == 0) {
        return cmd_optimize(argc - 1, argv + 1);
    } else if (strcmp(argv[1], "setup") == 0) {
        return cmd_setup(argc - 1, argv + 1);
    } else {
        fprintf(stderr, "Unknown command: %s\n", argv[1]);
        show_usage(argv[0]);
        return 1;
    }
    
    return 0;
}

static void show_usage(const char *prog_name)
{
    printf("\nZShell Kernel Isolation Framework Control Utility\n");
    printf("==============================================\n\n");
    printf("Usage: %s COMMAND [OPTIONS]\n\n", prog_name);
    printf("Commands:\n");
    printf("  setup             Initial setup of environment\n");
    printf("  start [OPTIONS]   Start isolated environment\n");
    printf("  stop              Stop isolated environment\n");
    printf("  status            Show status information\n");
    printf("  shell             Enter isolated environment shell\n");
    printf("  optimize          Optimize ZRAM compression\n");
    printf("\n");
    printf("Start options:\n");
    printf("  -r, --rootfs PATH    Path to system image or rootfs\n");
    printf("  -o, --overlay PATH   Path to overlay directory\n");
    printf("  -i, --init PATH      Path to init executable\n");
    printf("  -m, --mem-limit MB   Memory limit in MB (default: 2048)\n");
    printf("  -z, --zram           Enable advanced ZRAM (default: on)\n");
    printf("  -s, --ssh PORT       Enable SSH tunnel on PORT (default: 2022)\n");
    printf("\n");
    printf("Examples:\n");
    printf("  %s setup --firmware /sdcard/lineage-18.1.zip\n", prog_name);
    printf("  %s start --rootfs /data/local/zshell/system.img --mem-limit 4096\n", prog_name);
    printf("  %s shell\n", prog_name);
}

static int open_zshell_device(void)
{
    int fd = open(ZSHELL_DEVICE, O_RDWR);
    if (fd < 0) {
        perror("Failed to open ZShell device");
        fprintf(stderr, "Make sure the ZShell kernel module is loaded\n");
    }
    return fd;
}

static int cmd_start(int argc, char *argv[])
{
    int fd, ret, i;
    struct zshell_start_params params;
    
    /* Set default parameters */
    memset(&params, 0, sizeof(params));
    params.mem_limit_mb = 2048;
    params.flags = ZSHELL_FLAG_USE_ZRAM;  /* ZRAM enabled by default */
    params.ssh_port = 2022;
    
    /* Use default paths if not specified */
    snprintf(params.rootfs_path, sizeof(params.rootfs_path),
             "%s/system.img", CONFIG_DIR);
    snprintf(params.overlay_path, sizeof(params.overlay_path),
             "%s/overlay", CONFIG_DIR);
    snprintf(params.init_path, sizeof(params.init_path),
             "/init");
    
    /* Parse options */
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-r") == 0 || strcmp(argv[i], "--rootfs") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: Missing rootfs path\n");
                return 1;
            }
            snprintf(params.rootfs_path, sizeof(params.rootfs_path), "%s", argv[++i]);
        }
        else if (strcmp(argv[i], "-o") == 0 || strcmp(argv[i], "--overlay") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: Missing overlay path\n");
                return 1;
            }
            snprintf(params.overlay_path, sizeof(params.overlay_path), "%s", argv[++i]);
        }
        else if (strcmp(argv[i], "-i") == 0 || strcmp(argv[i], "--init") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: Missing init path\n");
                return 1;
            }
            snprintf(params.init_path, sizeof(params.init_path), "%s", argv[++i]);
        }
        else if (strcmp(argv[i], "-m") == 0 || strcmp(argv[i], "--mem-limit") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: Missing memory limit\n");
                return 1;
            }
            params.mem_limit_mb = atoi(argv[++i]);
            if (params.mem_limit_mb < 128 || params.mem_limit_mb > 8192) {
                fprintf(stderr, "Warning: Memory limit %d MB seems unusual\n",
                        params.mem_limit_mb);
            }
        }
        else if (strcmp(argv[i], "-z") == 0 || strcmp(argv[i], "--zram") == 0) {
            params.flags |= ZSHELL_FLAG_USE_ZRAM;
        }
        else if (strcmp(argv[i], "--no-zram") == 0) {
            params.flags &= ~ZSHELL_FLAG_USE_ZRAM;
        }
        else if (strcmp(argv[i], "-s") == 0 || strcmp(argv[i], "--ssh") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: Missing SSH port\n");
                return 1;
            }
            params.ssh_port = atoi(argv[++i]);
            params.flags |= ZSHELL_FLAG_USE_SSH;
        }
        else {
            fprintf(stderr, "Unknown option: %s\n", argv[i]);
            return 1;
        }
    }
    
    /* Validate parameters */
    struct stat st;
    if (stat(params.rootfs_path, &st) != 0) {
        fprintf(stderr, "Error: Rootfs not found: %s\n", params.rootfs_path);
        return 1;
    }
    
    /* Make sure overlay directory exists */
    if (stat(params.overlay_path, &st) != 0) {
        printf("Creating overlay directory: %s\n", params.overlay_path);
        if (mkdir(params.overlay_path, 0755) != 0) {
            perror("Failed to create overlay directory");
            return 1;
        }
    }
    
    /* Open device */
    fd = open_zshell_device();
    if (fd < 0)
        return 1;
    
    /* Start ZShell */
    printf("Starting ZShell isolated environment...\n");
    printf("  Rootfs: %s\n", params.rootfs_path);
    printf("  Overlay: %s\n", params.overlay_path);
    printf("  Memory limit: %d MB\n", params.mem_limit_mb);
    printf("  ZRAM: %s\n", (params.flags & ZSHELL_FLAG_USE_ZRAM) ? "enabled" : "disabled");
    
    if (params.flags & ZSHELL_FLAG_USE_SSH) {
        printf("  SSH tunnel: port %d\n", params.ssh_port);
    } else {
        printf("  SSH tunnel: disabled\n");
    }
    
    ret = ioctl(fd, ZSHELL_IOCTL_START, &params);
    if (ret < 0) {
        perror("Failed to start ZShell");
        close(fd);
        return 1;
    }
    
    printf(COLOR_GREEN "ZShell started successfully!\n" COLOR_RESET);
    
    /* Display connection information if SSH enabled */
    if (params.flags & ZSHELL_FLAG_USE_SSH) {
        printf("\nSSH access available:\n");
        printf("  ssh -p %d root@localhost\n", params.ssh_port);
        printf("  Key file: %s/ssh_key\n", CONFIG_DIR);
    }
    
    close(fd);
    return 0;
}

static int cmd_stop(int argc, char *argv[])
{
    int fd, ret;
    
    fd = open_zshell_device();
    if (fd < 0)
        return 1;
    
    printf("Stopping ZShell isolated environment...\n");
    
    ret = ioctl(fd, ZSHELL_IOCTL_STOP);
    if (ret < 0) {
        perror("Failed to stop ZShell");
        close(fd);
        return 1;
    }
    
    printf(COLOR_GREEN "ZShell stopped successfully\n" COLOR_RESET);
    close(fd);
    return 0;
}

static int cmd_status(int argc, char *argv[])
{
    int fd, ret;
    struct zshell_status status;
    
    fd = open_zshell_device();
    if (fd < 0)
        return 1;
    
    ret = ioctl(fd, ZSHELL_IOCTL_STATUS, &status);
    if (ret < 0) {
        perror("Failed to get ZShell status");
        close(fd);
        return 1;
    }
    
    printf("\nZShell Isolated Environment Status\n");
    printf("================================\n\n");
    
    if (status.running) {
        printf("Status: " COLOR_GREEN "Running" COLOR_RESET "\n");
        printf("PID: %d\n", status.pid);
        printf("Memory usage: %.1f MB\n", status.mem_used_kb / 1024.0);
        
        if (status.zram_used_kb > 0) {
            printf("\nZRAM Statistics:\n");
            printf("  Used memory: %.1f MB\n", status.zram_used_kb / 1024.0);
            printf("  Memory saved: %.1f MB\n", status.zram_saved_kb / 1024.0);
            printf("  Compression ratio: %.1f:1\n", status.compression_ratio / 100.0);
        }
        
        if (status.ssh_connections >= 0) {
            printf("\nSSH Connections: %d\n", status.ssh_connections);
        }
    } else {
        printf("Status: " COLOR_YELLOW "Stopped" COLOR_RESET "\n");
    }
    
    close(fd);
    return 0;
}

static int cmd_shell(int argc, char *argv[])
{
    int fd, ret;
    
    fd = open_zshell_device();
    if (fd < 0)
        return 1;
    
    printf("Entering ZShell isolated environment...\n");
    
    ret = ioctl(fd, ZSHELL_IOCTL_SHELL);
    if (ret < 0) {
        perror("Failed to enter ZShell");
        close(fd);
        return 1;
    }
    
    /* If we get here, we've returned from the shell */
    printf("Exited from ZShell environment\n");
    close(fd);
    return 0;
}

static int cmd_optimize(int argc, char *argv[])
{
    int fd, ret;
    int action = 0; /* 0 = compact, 1 = reset, 2 = stats */
    
    /* Parse action */
    if (argc > 1) {
        if (strcmp(argv[1], "compact") == 0) {
            action = 0;
        } else if (strcmp(argv[1], "reset") == 0) {
            action = 1;
        } else if (strcmp(argv[1], "stats") == 0) {
            action = 2;
        } else {
            fprintf(stderr, "Unknown optimize action: %s\n", argv[1]);
            fprintf(stderr, "Valid actions: compact, reset, stats\n");
            return 1;
        }
    }
    
    fd = open_zshell_device();
    if (fd < 0)
        return 1;
    
    printf("Optimizing ZRAM...\n");
    
    ret = ioctl(fd, ZSHELL_IOCTL_ZRAM_OPT, action);
    if (ret < 0) {
        perror("ZRAM optimization failed");
        close(fd);
        return 1;
    }
    
    /* Get status to show updated ZRAM info */
    struct zshell_status status;
    ret = ioctl(fd, ZSHELL_IOCTL_STATUS, &status);
    if (ret == 0 && status.running) {
        printf("\nZRAM Statistics after optimization:\n");
        printf("  Used memory: %.1f MB\n", status.zram_used_kb / 1024.0);
        printf("  Memory saved: %.1f MB\n", status.zram_saved_kb / 1024.0);
        printf("  Compression ratio: %.1f:1\n", status.compression_ratio / 100.0);
    }
    
    printf(COLOR_GREEN "ZRAM optimization completed\n" COLOR_RESET);
    close(fd);
    return 0;
}

static int cmd_setup(int argc, char *argv[])
{
    int ret = 0;
    const char *firmware_path = NULL;
    int i;
    
    /* Parse options */
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--firmware") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: Missing firmware path\n");
                return 1;
            }
            firmware_path = argv[++i];
        } else {
            fprintf(stderr, "Unknown option: %s\n", argv[i]);
            return 1;
        }
    }
    
    /* Check if firmware path is provided */
    if (!firmware_path) {
        fprintf(stderr, "Error: Firmware path required\n");
        fprintf(stderr, "Usage: %s setup --firmware PATH\n", argv[0]);
        return 1;
    }
    
    /* Check if firmware file exists */
    struct stat st;
    if (stat(firmware_path, &st) != 0) {
        fprintf(stderr, "Error: Firmware file not found: %s\n", firmware_path);
        return 1;
    }
    
    /* Create config directory */
    if (stat(CONFIG_DIR, &st) != 0) {
        printf("Creating config directory: %s\n", CONFIG_DIR);
        if (mkdir(CONFIG_DIR, 0755) != 0) {
            perror("Failed to create config directory");
            return 1;
        }
    }
    
    /* Create other directories */
    char dir[256];
    snprintf(dir, sizeof(dir), "%s/overlay", CONFIG_DIR);
    if (stat(dir, &st) != 0 && mkdir(dir, 0755) != 0) {
        perror("Failed to create overlay directory");
        return 1;
    }
    
    snprintf(dir, sizeof(dir), "%s/ssh", CONFIG_DIR);
    if (stat(dir, &st) != 0 && mkdir(dir, 0755) != 0) {
        perror("Failed to create SSH directory");
        return 1;
    }
    
    /* Extract system image from firmware */
    printf(COLOR_BLUE "Extracting system image from firmware...\n" COLOR_RESET);
    printf("This may take a few minutes.\n");
    
    char cmd[512];
    snprintf(cmd, sizeof(cmd), 
             "unzip -p %s 'system.img*' > %s/system.img.lz4 2>/dev/null || "
             "unzip -p %s 'AP*.tar.md5' | tar -xOf - system.img* > %s/system.img.lz4",
             firmware_path, CONFIG_DIR, firmware_path, CONFIG_DIR);
    
    ret = system(cmd);
    if (ret != 0) {
        fprintf(stderr, "Failed to extract system image from firmware\n");
        return 1;
    }
    
    /* Decompress if needed */
    snprintf(dir, sizeof(dir), "%s/system.img.lz4", CONFIG_DIR);
    if (stat(dir, &st) == 0) {
        printf("Decompressing system image...\n");
        snprintf(cmd, sizeof(cmd), "lz4 -d %s/system.img.lz4 %s/system.img",
                 CONFIG_DIR, CONFIG_DIR);
        ret = system(cmd);
        if (ret != 0) {
            fprintf(stderr, "Failed to decompress system image\n");
            return 1;
        }
        unlink(dir); /* Remove compressed file */
    }
    
    /* Generate SSH keys */
    printf("Generating SSH keys...\n");
    snprintf(cmd, sizeof(cmd), "ssh-keygen -t ed25519 -f %s/ssh/host_key -N \"\" >/dev/null",
             CONFIG_DIR);
    ret = system(cmd);
    if (ret != 0) {
        fprintf(stderr, "Warning: Failed to generate SSH host key\n");
    }
    
    snprintf(cmd, sizeof(cmd), "ssh-keygen -t ed25519 -f %s/ssh_key -N \"\" >/dev/null",
             CONFIG_DIR);
    ret = system(cmd);
    if (ret != 0) {
        fprintf(stderr, "Warning: Failed to generate SSH user key\n");
    } else {
        /* Set up authorized_keys */
        snprintf(cmd, sizeof(cmd), "cp