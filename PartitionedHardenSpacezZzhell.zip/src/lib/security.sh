#!/system/bin/sh
# Security library for AHIF
# Handles SSH access, encryption and key management

# SSH configuration constants
SSH_CONFIG="${AHIF_ROOT}/config/sshd_config"
SSH_AUTHORIZED_KEYS="${AHIF_KEYS}/authorized_keys"
DROPBEAR_PATH="${AHIF_ROOT}/bin/dropbear"

generate_ssh_keys() {
    log_info "Generating SSH keys"
    
    # Create keys directory
    mkdir -p "${AHIF_KEYS}"
    chmod 700 "${AHIF_KEYS}"
    
    # Generate host keys
    ssh-keygen -t "${ROOT_KEY_TYPE}" -f "${AHIF_KEYS}/ssh_host_${ROOT_KEY_TYPE}_key" -N "" || return 1
    
    # Generate user key pair if needed
    if [ ! -f "${AHIF_KEYS}/id_${ROOT_KEY_TYPE}" ]; then
        ssh-keygen -t "${ROOT_KEY_TYPE}" -f "${AHIF_KEYS}/id_${ROOT_KEY_TYPE}" -N "" || return 1
        cat "${AHIF_KEYS}/id_${ROOT_KEY_TYPE}.pub" > "${SSH_AUTHORIZED_KEYS}"
        chmod 600 "${SSH_AUTHORIZED_KEYS}"
    fi
    
    return 0
}

setup_ssh_access() {
    log_info "Setting up SSH access"
    
    # Create SSH configuration directory
    mkdir -p "$(dirname "${SSH_CONFIG}")"
    
    # Create SSH config
    cat > "${SSH_CONFIG}" << EOF
# AHIF SSH Server Configuration
Port ${SSH_PORT}
AuthorizedKeysFile ${SSH_AUTHORIZED_KEYS}
PermitRootLogin prohibit-password
PasswordAuthentication no
PermitEmptyPasswords no
ChallengeResponseAuthentication no
UsePAM no
X11Forwarding no
PrintMotd no
AcceptEnv LANG LC_*
Subsystem sftp internal-sftp
EOF
    
    # Set up minimal authorized_keys if needed
    if [ ! -f "${SSH_AUTHORIZED_KEYS}" ]; then
        mkdir -p "$(dirname "${SSH_AUTHORIZED_KEYS}")"
        touch "${SSH_AUTHORIZED_KEYS}"
        chmod 600 "${SSH_AUTHORIZED_KEYS}"
    fi
    
    # Check if we have dropbear or standard ssh
    if [ -x "${DROPBEAR_PATH}" ]; then
        log_info "Using Dropbear SSH implementation"
    elif command -v sshd > /dev/null; then
        log_info "Using OpenSSH implementation"
    else
        log_error "No SSH server implementation found"
        return 1
    fi
    
    return 0
}

start_ssh_server() {
    local port="$1"
    
    log_info "Starting SSH server on port ${port}"
    
    # Determine which SSH implementation to use
    if [ -x "${DROPBEAR_PATH}" ]; then
        # Start dropbear
        "${DROPBEAR_PATH}" -p "${port}" -r "${AHIF_KEYS}/ssh_host_${ROOT_KEY_TYPE}_key" \
            -F -E -P "${AHIF_ROOT}/run/dropbear.pid" || return 1
    else
        # Start OpenSSH
        /usr/sbin/sshd -f "${SSH_CONFIG}" -o "PidFile=${AHIF_ROOT}/run/sshd.pid" || return 1
    fi
    
    # Verify SSH server is running
    sleep 1
    if ! netstat -ln | grep -q ":${port}"; then
        log_error "SSH server failed to start on port ${port}"
        return 1
    fi
    
    log_info "SSH server started successfully"
    return 0
}

stop_ssh_server() {
    log_info "Stopping SSH server"
    
    # Try to kill by PID file first
    if [ -f "${AHIF_ROOT}/run/dropbear.pid" ]; then
        kill $(cat "${AHIF_ROOT}/run/dropbear.pid") 2>/dev/null || true
        rm -f "${AHIF_ROOT}/run/dropbear.pid"
    elif [ -f "${AHIF_ROOT}/run/sshd.pid" ]; then
        kill $(cat "${AHIF_ROOT}/run/sshd.pid") 2>/dev/null || true
        rm -f "${AHIF_ROOT}/run/sshd.pid"
    else
        # If no PID file, try to find and kill the process
        pkill -f "dropbear.*:${SSH_PORT}" 2>/dev/null || true
        pkill -f "sshd.*:${SSH_PORT}" 2>/dev/null || true
    fi
    
    # Verify SSH server is stopped
    if netstat -ln | grep -q ":${SSH_PORT}"; then
        log_warn "SSH server still running, forcing termination"
        pkill -9 -f "dropbear.*:${SSH_PORT}" 2>/dev/null || true
        pkill -9 -f "sshd.*:${SSH_PORT}" 2>/dev/null || true
        
        # Check again
        if netstat -ln | grep -q ":${SSH_PORT}"; then
            log_error "Failed to stop SSH server"
            return 1
        fi
    fi
    
    log_info "SSH server stopped successfully"
    return 0
}

check_capability() {
    local capability="$1"
    
    # Try to use capsh if available
    if command -v capsh > /dev/null; then
        capsh --print | grep -q "${capability}" && return 0
        return 1
    fi
    
    # Fallback to checking privileges based on uid
    if [ "$(id -u)" -eq 0 ]; then
        return 0
    fi
    
    return 1
}