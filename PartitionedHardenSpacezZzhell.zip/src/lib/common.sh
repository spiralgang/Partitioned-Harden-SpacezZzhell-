#!/system/bin/sh
# Common utilities library for AHIF
# Provides shared functions and logging capabilities

# Log levels
LOG_LEVEL_INFO=0
LOG_LEVEL_WARN=1
LOG_LEVEL_ERROR=2
CURRENT_LOG_LEVEL=${LOG_LEVEL_INFO}

init_logging() {
    # Create logs directory
    mkdir -p "$(dirname "${AHIF_LOG}")"
    touch "${AHIF_LOG}" 2>/dev/null || {
        # If we can't write to specified log, use fallback
        AHIF_LOG="/data/local/tmp/ahif.log"
        mkdir -p "$(dirname "${AHIF_LOG}")"
        touch "${AHIF_LOG}"
    }
    
    # Initialize log with header
    echo "=== AHIF Log Started $(date) ===" >> "${AHIF_LOG}"
}

log_message() {
    local level="$1"
    local message="$2"
    local level_name=""
    
    case "${level}" in
        ${LOG_LEVEL_INFO})
            level_name="INFO"
            ;;
        ${LOG_LEVEL_WARN})
            level_name="WARN"
            ;;
        ${LOG_LEVEL_ERROR})
            level_name="ERROR"
            ;;
        *)
            level_name="UNKNOWN"
            ;;
    esac
    
    # Only log if level is >= current log level
    if [ "${level}" -ge "${CURRENT_LOG_LEVEL}" ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${level_name}] ${message}" | tee -a "${AHIF_LOG}"
    fi
}

log_info() {
    log_message "${LOG_LEVEL_INFO}" "$1"
}

log_warn() {
    log_message "${LOG_LEVEL_WARN}" "$1"
}

log_error() {
    log_message "${LOG_LEVEL_ERROR}" "$1"
}

check_binaries() {
    local missing_bins=()
    
    for bin in "$@"; do
        if ! command -v "${bin}" > /dev/null; then
            missing_bins+=("${bin}")
        fi
    done
    
    if [ ${#missing_bins[@]} -gt 0 ]; then
        log_error "Missing required binaries: ${missing_bins[*]}"
        return 1
    fi
    
    return 0
}

validate_firmware() {
    local firmware_file="$1"
    
    if [ ! -f "${firmware_file}" ]; then
        log_error "Firmware file not found: ${firmware_file}"
        return 1
    fi
    
    # Check if file is a valid ZIP
    if ! unzip -l "${firmware_file}" >/dev/null 2>&1; then
        log_error "Invalid firmware file: not a valid ZIP file"
        return 1
    fi
    
    # Check for essential firmware components
    if ! unzip -l "${firmware_file}" | grep -q -e "system.img" -e "AP.*tar.md5"; then
        log_warn "Firmware may not contain system image"
    fi
    
    return 0
}