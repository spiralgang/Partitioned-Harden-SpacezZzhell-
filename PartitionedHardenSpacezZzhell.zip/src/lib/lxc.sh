#!/system/bin/sh
# LXC integration library for AHIF
# Handles container management and isolation

# LXC configuration
LXC_PATH="${AHIF_ROOT}/containers"
LXC_TEMPLATE="${AHIF_ROOT}/templates/android10.conf"
LXC_ROOTFS="${AHIF_SYSTEM}/rootfs"

start_lxc_container() {
    local container_name="$1"
    
    # Check if lxc-start exists
    if ! command -v lxc-start > /dev/null; then
        log_error "LXC tools not installed"
        return 1
    }
    
    # Create container configuration
    mkdir -p "${LXC_PATH}/${container_name}"
    cat > "${LXC_PATH}/${container_name}/config" << EOF
# Generated container config
lxc.uts.name = ${container_name}
lxc.rootfs.path = ${LXC_ROOTFS}
lxc.signal.halt = SIGTERM

# Network configuration - isolated
lxc.net.0.type = none

# Security settings
lxc.apparmor.profile = unconfined
lxc.cap.drop = 

# Resource limits
lxc.cgroup.devices.deny = a
lxc.cgroup.devices.allow = c *:* m
lxc.cgroup.memory.limit_in_bytes = 2G

# System mounts
lxc.mount.auto = proc sys cgroup
EOF
    
    # Start container
    lxc-start -n "${container_name}" -f "${LXC_PATH}/${container_name}/config" -d || {
        log_error "Failed to start LXC container ${container_name}"
        return 1
    }
    
    # Wait for container to be ready
    for i in $(seq 1 10); do
        if lxc-info -n "${container_name}" | grep -q "RUNNING"; then
            log_info "Container ${container_name} started successfully"
            return 0
        fi
        sleep 1
    done
    
    log_error "Container ${container_name} failed to start properly"
    return 1
}

stop_lxc_container() {
    local container_name="$1"
    
    # Check if container is running
    if ! lxc-info -n "${container_name}" | grep -q "RUNNING"; then
        log_info "Container ${container_name} is not running"
        return 0
    fi
    
    # Stop container
    lxc-stop -n "${container_name}" -t 10 || {
        log_warn "Failed to stop container gracefully, forcing shutdown"
        lxc-stop -n "${container_name}" -k
    }
    
    # Check if container stopped
    if lxc-info -n "${container_name}" | grep -q "STOPPED"; then
        log_info "Container ${container_name} stopped successfully"
        return 0
    else
        log_error "Failed to stop container ${container_name}"
        return 1
    fi
}

enter_shell() {
    local container_name="ahif-android"
    
    # Check if container is running
    if ! lxc-info -n "${container_name}" | grep -q "RUNNING"; then
        log_error "Container ${container_name} is not running"
        return 1
    }
    
    # Enter container shell
    log_info "Entering container shell"
    lxc-attach -n "${container_name}" -- /system/bin/sh
    return $?
}

check_status() {
    local container_name="ahif-android"
    
    # Check container status
    if lxc-info -n "${container_name}" 2>/dev/null; then
        # Check SSH status
        if netstat -ln | grep -q ":${SSH_PORT}"; then
            log_info "SSH server is running on port ${SSH_PORT}"
        else
            log_warn "SSH server is not running"
        fi
        
        # Show system stats
        log_info "System stats:"
        free -h
        
        return 0
    else
        log_info "Container ${container_name} is not created or running"
        return 1
    fi
}

setup_cgroups() {
    local cgroup_name="$1"
    
    # Check for cgroups v2
    if [ -d "/sys/fs/cgroup/cgroup.controllers" ]; then
        # Using cgroups v2
        mkdir -p "/sys/fs/cgroup/${cgroup_name}" 2>/dev/null || true
        echo "+memory +cpu +io" > "/sys/fs/cgroup/${cgroup_name}/cgroup.subtree_control" 2>/dev/null || true
        echo "2G" > "/sys/fs/cgroup/${cgroup_name}/memory.max" 2>/dev/null || true
        echo "100000 100000" > "/sys/fs/cgroup/${cgroup_name}/cpu.max" 2>/dev/null || true
    elif [ -d "/sys/fs/cgroup/memory" ]; then
        # Using cgroups v1
        mkdir -p "/sys/fs/cgroup/memory/${cgroup_name}" 2>/dev/null || true
        mkdir -p "/sys/fs/cgroup/cpu/${cgroup_name}" 2>/dev/null || true
        echo "2G" > "/sys/fs/cgroup/memory/${cgroup_name}/memory.limit_in_bytes" 2>/dev/null || true
        echo "100000" > "/sys/fs/cgroup/cpu/${cgroup_name}/cpu.cfs_quota_us" 2>/dev/null || true
    else
        log_warn "No cgroups filesystem found"
        return 1
    fi
    
    return 0
}