#!/system/bin/sh
# Hardened Android Isolation Framework (HAIF)
# For Samsung SM-G965U1 (Galaxy S9+) running Android 10
# Creates fully isolated Android environment with dedicated kernel namespace

set -eo pipefail

HAIF_VERSION="1.0.0"
HAIF_ROOT="/data/local/hardened_android"
HAIF_KERNEL="${HAIF_ROOT}/kernel"
HAIF_SYSTEM="${HAIF_ROOT}/system"
HAIF_DATA="${HAIF_ROOT}/data"
HAIF_CONFIG="${HAIF_ROOT}/config"
HAIF_BIN="${HAIF_ROOT}/bin"
HAIF_LOG="${HAIF_ROOT}/logs/haif.log"

# Samsung-specific settings
DEVICE_MODEL="SM-G965U1"
SOC_TYPE="exynos9810"
KERNEL_VERSION="4.9.186"

source "${HAIF_ROOT}/lib/logging.sh"
source "${HAIF_ROOT}/lib/zram_controller.sh"
source "${HAIF_ROOT}/lib/namespace_controller.sh"
source "${HAIF_ROOT}/lib/mount_controller.sh"
source "${HAIF_ROOT}/lib/chisel_controller.sh"

log_info "Initializing HAIF v${HAIF_VERSION} for ${DEVICE_MODEL}..."

# Establish mount namespaces for isolation
setup_mount_namespace() {
    log_info "Setting up mount namespace..."
    if ! unshare -m /bin/sh -c "mount -t proc proc /proc && echo success" | grep -q success; then
        log_error "Failed to create mount namespace. Check kernel capabilities."
        return 1
    fi
    return 0
}

# Create layered filesystem with CoW support
setup_layered_fs() {
    log_info "Setting up layered filesystem..."
    if [ ! -f "${HAIF_SYSTEM}/system.img" ]; then
        log_error "System image not found at ${HAIF_SYSTEM}/system.img"
        return 1
    fi
    
    # Mount base readonly layer
    mount -o loop,ro "${HAIF_SYSTEM}/system.img" "${HAIF_SYSTEM}/ro" || {
        log_error "Failed to mount readonly system image"
        return 1
    }
    
    # Create overlay with CoW
    mount -t overlay overlay \
        -o lowerdir=${HAIF_SYSTEM}/ro,upperdir=${HAIF_SYSTEM}/rw,workdir=${HAIF_SYSTEM}/work \
        ${HAIF_SYSTEM}/fs || {
        log_error "Failed to mount overlay filesystem"
        umount "${HAIF_SYSTEM}/ro" 2>/dev/null || true
        return 1
    }
    
    return 0
}

# Initialize ZRAM with Samsung optimizations
init_optimized_zram() {
    log_info "Initializing optimized ZRAM..."
    
    # Samsung devices have specific ZRAM capabilities
    local available_mem=$(cat /proc/meminfo | grep MemTotal | awk '{print $2}')
    local zram_size=$((available_mem / 2))
    
    setup_zram ${zram_size} "lz4" 100
    
    # Enable Samsung-specific memory deduplication if available
    if [ -f "/sys/block/zram0/use_dedup" ]; then
        echo 1 > /sys/block/zram0/use_dedup
        log_info "Enabled Samsung memory deduplication"
    fi
    
    return 0
}

# Setup kernel isolation with namespace separation
setup_kernel_isolation() {
    log_info "Setting up kernel isolation..."
    
    # Create isolated namespaces
    unshare -mpf --mount-proc "${HAIF_BIN}/init_isolated_ns" || {
        log_error "Failed to create isolated namespaces"
        return 1
    }
    
    # Configure cgroup isolation if available
    if [ -d "/sys/fs/cgroup" ]; then
        create_isolated_cgroup "haif_isolated" || log_warn "Failed to create isolated cgroup"
    else
        log_warn "Cgroup filesystem not available, reduced isolation"
    fi
    
    return 0
}

# Build chisel container definition
create_container_def() {
    log_info "Creating container definition..."
    
    cat > "${HAIF_CONFIG}/container.json" << EOF
{
  "ociVersion": "1.0.0",
  "process": {
    "terminal": true,
    "user": { "uid": 0, "gid": 0 },
    "args": ["/system/bin/sh"],
    "env": [
      "PATH=/system/bin:/system/xbin:/vendor/bin",
      "ANDROID_ROOT=/system",
      "ANDROID_DATA=/data",
      "ANDROID_STORAGE=/storage"
    ],
    "cwd": "/",
    "capabilities": {
      "bounding": ["CAP_AUDIT_CONTROL", "CAP_AUDIT_READ", "CAP_AUDIT_WRITE", "CAP_BLOCK_SUSPEND", "CAP_CHOWN", "CAP_DAC_OVERRIDE", "CAP_DAC_READ_SEARCH", "CAP_FOWNER", "CAP_FSETID", "CAP_IPC_LOCK", "CAP_IPC_OWNER", "CAP_KILL", "CAP_LEASE", "CAP_LINUX_IMMUTABLE", "CAP_MAC_ADMIN", "CAP_MAC_OVERRIDE", "CAP_MKNOD", "CAP_NET_ADMIN", "CAP_NET_BIND_SERVICE", "CAP_NET_BROADCAST", "CAP_NET_RAW", "CAP_SETGID", "CAP_SETFCAP", "CAP_SETPCAP", "CAP_SETUID", "CAP_SYS_ADMIN", "CAP_SYS_BOOT", "CAP_SYS_CHROOT", "CAP_SYS_MODULE", "CAP_SYS_NICE", "CAP_SYS_PACCT", "CAP_SYS_PTRACE", "CAP_SYS_RAWIO", "CAP_SYS_RESOURCE", "CAP_SYS_TIME", "CAP_SYS_TTY_CONFIG", "CAP_SYSLOG", "CAP_WAKE_ALARM"],
      "effective": ["CAP_AUDIT_CONTROL", "CAP_AUDIT_READ", "CAP_AUDIT_WRITE", "CAP_BLOCK_SUSPEND", "CAP_CHOWN", "CAP_DAC_OVERRIDE", "CAP_DAC_READ_SEARCH", "CAP_FOWNER", "CAP_FSETID", "CAP_IPC_LOCK", "CAP_IPC_OWNER", "CAP_KILL", "CAP_LEASE", "CAP_LINUX_IMMUTABLE", "CAP_MAC_ADMIN", "CAP_MAC_OVERRIDE", "CAP_MKNOD", "CAP_NET_ADMIN", "CAP_NET_BIND_SERVICE", "CAP_NET_BROADCAST", "CAP_NET_RAW", "CAP_SETGID", "CAP_SETFCAP", "CAP_SETPCAP", "CAP_SETUID", "CAP_SYS_ADMIN", "CAP_SYS_BOOT", "CAP_SYS_CHROOT", "CAP_SYS_MODULE", "CAP_SYS_NICE", "CAP_SYS_PACCT", "CAP_SYS_PTRACE", "CAP_SYS_RAWIO", "CAP_SYS_RESOURCE", "CAP_SYS_TIME", "CAP_SYS_TTY_CONFIG", "CAP_SYSLOG", "CAP_WAKE_ALARM"],
      "inheritable": ["CAP_AUDIT_CONTROL", "CAP_AUDIT_READ", "CAP_AUDIT_WRITE", "CAP_BLOCK_SUSPEND", "CAP_CHOWN", "CAP_DAC_OVERRIDE", "CAP_DAC_READ_SEARCH", "CAP_FOWNER", "CAP_FSETID", "CAP_IPC_LOCK", "CAP_IPC_OWNER", "CAP_KILL", "CAP_LEASE", "CAP_LINUX_IMMUTABLE", "CAP_MAC_ADMIN", "CAP_MAC_OVERRIDE", "CAP_MKNOD", "CAP_NET_ADMIN", "CAP_NET_BIND_SERVICE", "CAP_NET_BROADCAST", "CAP_NET_RAW", "CAP_SETGID", "CAP_SETFCAP", "CAP_SETPCAP", "CAP_SETUID", "CAP_SYS_ADMIN", "CAP_SYS_BOOT", "CAP_SYS_CHROOT", "CAP_SYS_MODULE", "CAP_SYS_NICE", "CAP_SYS_PACCT", "CAP_SYS_PTRACE", "CAP_SYS_RAWIO", "CAP_SYS_RESOURCE", "CAP_SYS_TIME", "CAP_SYS_TTY_CONFIG", "CAP_SYSLOG", "CAP_WAKE_ALARM"]
    },
    "rlimits": [
      { "type": "RLIMIT_NOFILE", "hard": 1024, "soft": 1024 }
    ],
    "noNewPrivileges": false
  },
  "root": {
    "path": "${HAIF_SYSTEM}/fs",
    "readonly": false
  },
  "mounts": [
    { "destination": "/proc", "type": "proc", "source": "proc" },
    { "destination": "/dev", "type": "tmpfs", "source": "tmpfs", "options": ["nosuid", "strictatime", "mode=755", "size=65536k"] },
    { "destination": "/dev/pts", "type": "devpts", "source": "devpts", "options": ["nosuid", "noexec", "newinstance", "ptmxmode=0666", "mode=0620"] },
    { "destination": "/dev/shm", "type": "tmpfs", "source": "shm", "options": ["nosuid", "noexec", "nodev", "mode=1777", "size=65536k"] },
    { "destination": "/sys", "type": "sysfs", "source": "sysfs", "options": ["nosuid", "noexec", "nodev", "ro"] },
    { "destination": "/data", "type": "none", "source": "${HAIF_DATA}", "options": ["rbind", "rw"] }
  ],
  "linux": {
    "resources": {
      "devices": [
        { "allow": false, "access": "rwm" }
      ],
      "memory": {
        "limit": 2147483648,
        "reservation": 536870912,
        "swap": 1073741824,
        "swappiness": 60
      },
      "cpu": {
        "shares": 1024,
        "quota": 100000,
        "period": 100000
      }
    },
    "namespaces": [
      { "type": "pid" },
      { "type": "ipc" },
      { "type": "uts" },
      { "type": "mount" },
      { "type": "user" }
    ],
    "seccomp": {
      "defaultAction": "SCMP_ACT_ALLOW"
    }
  }
}
EOF
    
    return 0
}

main() {
    # Create required directories
    mkdir -p "${HAIF_ROOT}" "${HAIF_KERNEL}" "${HAIF_SYSTEM}"/{ro,rw,work,fs} \
             "${HAIF_DATA}" "${HAIF_CONFIG}" "${HAIF_BIN}" "$(dirname "${HAIF_LOG}")"
    
    # Initialize components
    setup_mount_namespace || exit 1
    init_optimized_zram || log_warn "ZRAM initialization failed, continuing with reduced performance"
    setup_layered_fs || exit 1
    setup_kernel_isolation || exit 1
    create_container_def || exit 1
    
    log_info "HAIF framework initialized successfully"
    return 0
}

main "$@"