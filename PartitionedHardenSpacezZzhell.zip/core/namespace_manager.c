/**
 * Namespace Manager
 * 
 * Manages Linux namespaces for complete isolation
 * of the Android environment.
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/sched.h>
#include <linux/nsproxy.h>
#include <linux/mount.h>
#include <linux/fs.h>
#include <linux/fs_struct.h>
#include <linux/namei.h>
#include <linux/path.h>
#include <linux/slab.h>
#include <linux/cred.h>
#include "namespace_manager.h"

/**
 * Setup overlay filesystem mounting
 * 
 * Creates a writable layer over the read-only system image
 * using overlayfs for proper isolation
 * 
 * @param lower_dir: Path to read-only system image mountpoint
 * @param upper_dir: Path to writable layer
 * @return 0 on success, error code otherwise
 */
int namespace_manager_setup_overlay(const char *lower_dir, const char *upper_dir)
{
    int ret = 0;
    struct path lower_path, upper_path, work_path, target_path;
    char *work_dir = NULL;
    char *target_dir = NULL;
    char *options = NULL;
    
    /* Create work directory path from upper_dir */
    work_dir = kasprintf(GFP_KERNEL, "%s_work", upper_dir);
    if (!work_dir)
        return -ENOMEM;
    
    /* Create target mount directory path */
    target_dir = kasprintf(GFP_KERNEL, "%s_mount", lower_dir);
    if (!target_dir) {
        ret = -ENOMEM;
        goto out_free_work;
    }
    
    /* Lookup paths */
    ret = kern_path(lower_dir, LOOKUP_FOLLOW, &lower_path);
    if (ret)
        goto out_free_target;
    
    ret = kern_path(upper_dir, LOOKUP_FOLLOW, &upper_path);
    if (ret)
        goto out_put_lower;
    
    ret = kern_path(work_dir, LOOKUP_FOLLOW, &work_path);
    if (ret)
        goto out_put_upper;
    
    ret = kern_path(target_dir, LOOKUP_FOLLOW, &target_path);
    if (ret)
        goto out_put_work;
    
    /* Prepare overlay mount options */
    options = kasprintf(GFP_KERNEL, 
                "lowerdir=%s,upperdir=%s,workdir=%s",
                lower_dir, upper_dir, work_dir);
    if (!options) {
        ret = -ENOMEM;
        goto out_put_target;
    }
    
    /* Perform the actual overlay mount */
    ret = vfs_kern_mount_overlay(options, &target_path);
    if (ret) {
        pr_err("namespace: Failed to mount overlay filesystem\n");
        goto out_free_options;
    }
    
    pr_info("namespace: Successfully mounted overlay filesystem\n");
    
out_free_options:
    kfree(options);
out_put_target:
    path_put(&target_path);
out_put_work:
    path_put(&work_path);
out_put_upper:
    path_put(&upper_path);
out_put_lower:
    path_put(&lower_path);
out_free_target:
    kfree(target_dir);
out_free_work:
    kfree(work_dir);
    
    return ret;
}
EXPORT_SYMBOL_GPL(namespace_manager_setup_overlay);

/**
 * Mount a special filesystem in the isolated environment
 * 
 * @param type: Type of filesystem (proc, sysfs, devtmpfs, etc.)
 * @param path: Mount point
 * @return 0 on success, error code otherwise
 */
int namespace_manager_mount_special(const char *type, const char *path)
{
    int ret = 0;
    struct path target_path;
    
    /* Lookup target path */
    ret = kern_path(path, LOOKUP_FOLLOW, &target_path);
    if (ret) {
        /* If path doesn't exist, create it */
        ret = vfs_mkdir(current->fs->root.dentry, path, 0755);
        if (ret)
            return ret;
        
        ret = kern_path(path, LOOKUP_FOLLOW, &target_path);
        if (ret)
            return ret;
    }
    
    /* Mount the special filesystem */
    if (strcmp(type, "proc") == 0) {
        ret = vfs_kern_mount_procfs(&target_path);
    } else if (strcmp(type, "sysfs") == 0) {
        ret = vfs_kern_mount_sysfs(&target_path);
    } else if (strcmp(type, "devtmpfs") == 0) {
        ret = vfs_kern_mount_devtmpfs(&target_path);
    } else {
        ret = -EINVAL;
    }
    
    path_put(&target_path);
    return ret;
}
EXPORT_SYMBOL_GPL(namespace_manager_mount_special);

/**
 * Create and enter a new mount namespace
 * 
 * @return 0 on success, error code otherwise
 */
int namespace_manager_create_mnt_ns(void)
{
    struct nsproxy *ns = current->nsproxy;
    struct mnt_namespace *mnt_ns;
    int ret;
    
    /* Create a new mount namespace */
    mnt_ns = copy_mnt_ns(ns->mnt_ns, ns->user_ns);
    if (IS_ERR(mnt_ns))
        return PTR_ERR(mnt_ns);
    
    /* Switch to the new namespace */
    put_mnt_ns(ns->mnt_ns);
    ns->mnt_ns = mnt_ns;
    
    return 0;
}
EXPORT_SYMBOL_GPL(namespace_manager_create_mnt_ns);

/**
 * Helper function to perform overlay mount via VFS
 */
static int vfs_kern_mount_overlay(const char *options, struct path *path)
{
    struct file_system_type *fs_type;
    struct vfsmount *mnt;
    
    fs_type = get_fs_type("overlay");
    if (!fs_type)
        return -ENODEV;
    
    mnt = vfs_kern_mount(fs_type, 0, "overlay", options);
    if (IS_ERR(mnt)) {
        put_filesystem(fs_type);
        return PTR_ERR(mnt);
    }
    
    /* Replace the existing mount point with our new one */
    mntput(path->mnt);
    path->mnt = mnt;
    
    put_filesystem(fs_type);
    return 0;
}

/**
 * Helper function to mount procfs via VFS
 */
static int vfs_kern_mount_procfs(struct path *path)
{
    struct file_system_type *fs_type;
    struct vfsmount *mnt;
    
    fs_type = get_fs_type("proc");
    if (!fs_type)
        return -ENODEV;
    
    mnt = vfs_kern_mount(fs_type, 0, "proc", NULL);
    if (IS_ERR(mnt)) {
        put_filesystem(fs_type);
        return PTR_ERR(mnt);
    }
    
    mntput(path->mnt);
    path->mnt = mnt;
    
    put_filesystem(fs_type);
    return 0;
}

/**
 * Helper function to mount sysfs via VFS
 */
static int vfs_kern_mount_sysfs(struct path *path)
{
    struct file_system_type *fs_type;
    struct vfsmount *mnt;
    
    fs_type = get_fs_type("sysfs");
    if (!fs_type)
        return -ENODEV;
    
    mnt = vfs_kern_mount(fs_type, 0, "sysfs", NULL);
    if (IS_ERR(mnt)) {
        put_filesystem(fs_type);
        return PTR_ERR(mnt);
    }
    
    mntput(path->mnt);
    path->mnt = mnt;
    
    put_filesystem(fs_type);
    return 0;
}

/**
 * Helper function to mount devtmpfs via VFS
 */
static int vfs_kern_mount_devtmpfs(struct path *path)
{
    struct file_system_type *fs_type;
    struct vfsmount *mnt;
    
    fs_type = get_fs_type("devtmpfs");
    if (!fs_type)
        return -ENODEV;
    
    mnt = vfs_kern_mount(fs_type, 0, "devtmpfs", "mode=755");
    if (IS_ERR(mnt)) {
        put_filesystem(fs_type);
        return PTR_ERR(mnt);
    }
    
    mntput(path->mnt);
    path->mnt = mnt;
    
    put_filesystem(fs_type);
    return 0;
}