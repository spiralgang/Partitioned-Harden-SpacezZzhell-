#!/bin/bash
set -euo pipefail

# === CONFIGURATION ===
CELL_NAME="android10_isolated"
CELL_BASE="/data/local/tmp/${CELL_NAME}"
FIRMWARE_ZIP="/path/to/SM-G965U1_XAR_G965U1UES9FVD1.zip"
ANDROID_VERSION="10"
CHISEL_VERSION="v0.8.1" # Latest compatible with Android 10

# === INSTALL DEPENDENCIES ===
echo "[+] Installing dependencies..."
apt update
apt install -y unzip wget p7zip-full simg2img proot util-linux lz4 curl jq

# === DOWNLOAD CHISEL ===
echo "[+] Setting up Chisel..."
ARCH=$(uname -m)
if [ ! -f "/usr/local/bin/chisel" ]; then
    curl -L "https://github.com/canonical/chisel/releases/download/${CHISEL_VERSION}/chisel-${ARCH}" -o /usr/local/bin/chisel
    chmod +x /usr/local/bin/chisel
fi

# === EXTRACT THE SYSTEM IMAGE ===
echo "[+] Extracting firmware and converting system.img..."
EXTRACT_DIR=$(mktemp -d)
cd "${EXTRACT_DIR}"

# Extract AP package from firmware
unzip -j "${FIRMWARE_ZIP}" "AP*.tar.md5" || { echo "[-] Failed to extract AP tar"; exit 1; }
AP_TAR=$(ls AP*.tar.md5 | head -n1)
tar -xf "${AP_TAR}" "system.img.lz4" || { echo "[-] Failed to extract system.img.lz4"; exit 1; }
lz4 -d "system.img.lz4" system.img.raw || { echo "[-] Decompression failed"; exit 1; }
simg2img system.img.raw system.img || { echo "[-] Image conversion failed"; exit 1; }

# === CREATE ISOLATED ENVIRONMENT ===
echo "[+] Building isolated Android environment..."
mkdir -p "${CELL_BASE}/rootfs"
mkdir -p "${CELL_BASE}/overlay" "${CELL_BASE}/workdir"

# Mount system image as read-only
mkdir -p "${CELL_BASE}/system_ro"
mount -o loop,ro "${EXTRACT_DIR}/system.img" "${CELL_BASE}/system_ro"

# Create overlay mount
mount -t overlay overlay \
    -o lowerdir="${CELL_BASE}/system_ro",upperdir="${CELL_BASE}/overlay",workdir="${CELL_BASE}/workdir" \
    "${CELL_BASE}/rootfs"

# === SETUP ZRAM ===
echo "[+] Configuring ZRAM..."
# Create ZRAM config
cat > "${CELL_BASE}/rootfs/etc/zram.conf" << EOF
# ZRAM Configuration
ZRAM_NUM_DEVICES=2
ZRAM_SIZE_MB=512
ZRAM_ALGORITHM=lz4
EOF

# Create ZRAM initialization script
cat > "${CELL_BASE}/rootfs/etc/init.d/zram" << EOF
#!/bin/sh
modprobe zram num_devices=\${ZRAM_NUM_DEVICES:-2}

for i in \$(seq 0 \$((ZRAM_NUM_DEVICES-1))); do
    echo \${ZRAM_ALGORITHM:-lz4} > /sys/block/zram\$i/comp_algorithm
    echo \$((ZRAM_SIZE_MB*1024*1024)) > /sys/block/zram\$i/disksize
    mkswap /dev/zram\$i
    swapon -p 100 /dev/zram\$i
done
EOF
chmod +x "${CELL_BASE}/rootfs/etc/init.d/zram"

# === CREATE CONTAINER ===
echo "[+] Creating Chisel container definition..."
mkdir -p "${CELL_BASE}/container"

cat > "${CELL_BASE}/container/config.json" << EOF
{
  "ociVersion": "1.0.0",
  "process": {
    "terminal": true,
    "user": {
      "uid": 0,
      "gid": 0
    },
    "args": ["/bin/sh"],
    "env": [
      "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
      "TERM=xterm"
    ],
    "cwd": "/",
    "capabilities": {
      "bounding": ["CAP_AUDIT_WRITE", "CAP_KILL", "CAP_NET_BIND_SERVICE"],
      "effective": ["CAP_AUDIT_WRITE", "CAP_KILL", "CAP_NET_BIND_SERVICE"],
      "inheritable": ["CAP_AUDIT_WRITE", "CAP_KILL", "CAP_NET_BIND_SERVICE"],
      "permitted": ["CAP_AUDIT_WRITE", "CAP_KILL", "CAP_NET_BIND_SERVICE"]
    },
    "rlimits": [
      {
        "type": "RLIMIT_NOFILE",
        "hard": 1024,
        "soft": 1024
      }
    ]
  },
  "root": {
    "path": "${CELL_BASE}/rootfs",
    "readonly": false
  },
  "mounts": [
    {
      "destination": "/proc",
      "type": "proc",
      "source": "proc"
    },
    {
      "destination": "/dev",
      "type": "tmpfs",
      "source": "tmpfs",
      "options": ["nosuid", "strictatime", "mode=755", "size=65536k"]
    },
    {
      "destination": "/sys",
      "type": "sysfs",
      "source": "sysfs",
      "options": ["nosuid", "noexec", "nodev", "ro"]
    }
  ],
  "linux": {
    "resources": {
      "memory": {
        "limit": 512000000
      },
      "cpu": {
        "shares": 1024
      }
    },
    "namespaces": [
      {
        "type": "pid"
      },
      {
        "type": "network"
      },
      {
        "type": "ipc"
      },
      {
        "type": "uts"
      },
      {
        "type": "mount"
      }
    ]
  }
}
EOF

# === CREATE ENTRY SCRIPT ===
cat > "${CELL_BASE}/enter_isolated_android.sh" << EOF
#!/system/bin/sh
CELL_BASE="${CELL_BASE}"

if ! mountpoint -q "\${CELL_BASE}/rootfs"; then
    mount -t overlay overlay \
        -o lowerdir="\${CELL_BASE}/system_ro",upperdir="\${CELL_BASE}/overlay",workdir="\${CELL_BASE}/workdir" \
        "\${CELL_BASE}/rootfs"
fi

exec proot -r "\${CELL_BASE}/rootfs" \
    -b /dev \
    -b /proc \
    -w / \
    /system/bin/sh
EOF
chmod +x "${CELL_BASE}/enter_isolated_android.sh"

echo "[+] Cleaning up..."
umount "${CELL_BASE}/system_ro" || true
rm -rf "${EXTRACT_DIR}"

echo "[+] =================================================="
echo "[+] ISOLATED ANDROID ENVIRONMENT SETUP COMPLETE"
echo "[+] =================================================="
echo "[+] To enter the environment, run:"
echo "[+] ${CELL_BASE}/enter_isolated_android.sh"
echo "[+] =================================================="