#!/bin/bash
# Android 10 (API 29) Compatibility Fixes for ZShell
# Target: SM-G965U1 (Galaxy S9+)

# SELinux context handling for Android 10
fix_selinux_contexts() {
  if command -v chcon &>/dev/null; then
    echo "Setting proper SELinux contexts for overlay mounts..."
    chcon -R u:object_r:system_file:s0 "${ZSHELL_ROOT}/rootfs"
  fi
}

# Handle Android 10 specific filesystem restrictions
android10_fs_workarounds() {
  # Create Android 10 compatible device nodes
  if [ -d "${ZSHELL_ROOT}/rootfs/dev" ]; then
    # Android 10 requires specific device permissions
    mount -o remount,exec,dev "${ZSHELL_ROOT}/rootfs/dev"
    
    # Fix for Android 10's more restrictive /proc handling
    if [ -d "${ZSHELL_ROOT}/rootfs/proc" ]; then
      mount -o remount,hidepid=0 "${ZSHELL_ROOT}/rootfs/proc"
    fi
  fi
}

# Samsung OneUI 2.0 specific optimizations (Android 10 on S9+)
oneui_optimizations() {
  # Ensure ZRAM compatibility with Samsung's kernel
  if [ -f /sys/block/zram0/comp_algorithm ]; then
    # Samsung's Android 10 ZRAM prefers lz4 over zstd
    echo "lz4" > /sys/block/zram0/comp_algorithm 2>/dev/null || true
    
    # Enable Samsung memory deduplication if available
    if [ -f /sys/block/zram0/use_dedup ]; then
      echo 1 > /sys/block/zram0/use_dedup 2>/dev/null || true
    fi
  fi
}

# Apply all Android 10 compatibility fixes
apply_android10_fixes() {
  fix_selinux_contexts
  android10_fs_workarounds
  oneui_optimizations
  
  echo "Android 10 compatibility fixes applied successfully"
}

apply_android10_fixes