#!/bin/bash

# UserLAnd Configuration Automation Script
# For Android 10+ compatibility
# Author: spiralgang

set -e  # Exit on errors

# Config directory paths - adjust as needed for your UserLAnd setup
CONFIG_DIRS=(
  "$HOME/userland/apps"
  "$HOME/userland/filesystems"
  "$HOME/.config/userland"
)

# Backup directory
BACKUP_DIR="$HOME/.userland_backups/$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

# Check for required tools
for cmd in jq xmlstarlet grep sed; do
  if ! command -v $cmd &> /dev/null; then
    echo "[$cmd] required but not found. Installing..."
    apt-get update && apt-get install -y $cmd
  fi
done

# Create backup of a file before modifying
backup_file() {
  local file="$1"
  local rel_path="${file#$HOME/}"
  local backup_path="$BACKUP_DIR/$rel_path"
  mkdir -p "$(dirname "$backup_path")"
  cp -p "$file" "$backup_path"
  echo "Backed up: $file"
}

# Process JSON files
process_json() {
  local file="$1"
  echo "Processing JSON: $file"
  backup_file "$file"
  
  # Example: Modify security policies to allow your user
  if grep -q "enforcement" "$file"; then
    jq '.conditions[0].pattern = "spiralgang" | 
        .description = "Modified by UserLAnd automation script"' "$file" > "$file.tmp"
    mv "$file.tmp" "$file"
    echo "  Updated security policy"
  fi
  
  # Add more JSON transformations as needed
}

# Process TOML files
process_toml() {
  local file="$1"
  echo "Processing TOML: $file"
  backup_file "$file"
  
  # Without a proper TOML parser, we use sed for basic modifications
  sed -i 's/edition = "2021"/edition = "2021" # Modified by automation/g' "$file"
  sed -i 's/tokio = { version = "1.0"/tokio = { version = "1.2"/g' "$file"
  
  echo "  Updated TOML configuration"
}

# Process XML files
process_xml() {
  local file="$1"
  echo "Processing XML: $file"
  backup_file "$file"
  
  # Example: Update Android manifest attributes
  xmlstarlet ed -L \
    -u "/manifest/application/@android:label" -v "UserLAnd-Custom" \
    -u "/manifest/application/@android:theme" -v "@android:style/Theme.DeviceDefault" \
    "$file"
  
  echo "  Updated XML configuration"
}

# Process filesystem configurations
process_fs_config() {
  local file="$1"
  echo "Processing filesystem config: $file"
  backup_file "$file"
  
  # Example: Update filesystem mount options
  sed -i 's/ro,/rw,noatime,/g' "$file"
  
  echo "  Updated filesystem configuration"
}

# Main processing function
process_file() {
  local file="$1"
  
  case "$file" in
    *.json)
      process_json "$file"
      ;;
    *.toml|Cargo.toml)
      process_toml "$file"
      ;;
    *.xml)
      process_xml "$file"
      ;;
    *filesystem*.conf)
      process_fs_config "$file"
      ;;
    *)
      echo "Skipping unknown file type: $file"
      ;;
  esac
}

# Main script execution
echo "Starting UserLAnd configuration automation..."
echo "Creating backups in: $BACKUP_DIR"

# Process all configuration files
for dir in "${CONFIG_DIRS[@]}"; do
  if [ -d "$dir" ]; then
    echo "Scanning directory: $dir"
    find "$dir" -type f \( -name "*.json" -o -name "*.toml" -o -name "*.xml" -o -name "*.conf" \) | while read file; do
      process_file "$file"
    done
  else
    echo "Directory not found, skipping: $dir"
  fi
done

# Apply global UserLAnd settings
if [ -f "$HOME/.userland_profile" ]; then
  echo "Updating global UserLAnd profile"
  backup_file "$HOME/.userland_profile"
  
  # Add custom environment variables
  if ! grep -q "CUSTOM_ENV_SET" "$HOME/.userland_profile"; then
    echo -e "\n# Custom environment settings - CUSTOM_ENV_SET\n" >> "$HOME/.userland_profile"
    echo "export ANDROID_COMPATIBILITY=10" >> "$HOME/.userland_profile"
    echo "export PATH=\$HOME/bin:\$PATH" >> "$HOME/.userland_profile"
  fi
fi

echo "Configuration automation complete!"
echo "Backup files stored in: $BACKUP_DIR"