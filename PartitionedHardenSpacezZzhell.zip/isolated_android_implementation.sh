#!/bin/bash
# =================================================================
# Isolated Android Environment Implementation using:
# - Chisel Containerization (v0.8.1+)
# - ZRAM Compression with Samsung optimizations
# - Overlay Filesystem for Android 10 (SM-G965U1)
# - UserLAnd Integration (aarch64)
# =================================================================
set -euo pipefail

# ================ CONFIGURATION VARIABLES ================ #
CELL_NAME="android10_isolated"
CELL_BASE="/data/local/tmp/${CELL_NAME}"
FIRMWARE_URL=""  # Set to actual firmware URL
FIRMWARE_ZIP="/path/to/downloaded/SM-G965U1_XAR_G965U1UES9FVD1.zip"
ANDROID_VERSION="10"
CHISEL_VERSION="v0.8.1"
LOG_FILE="${CELL_BASE}/setup.log"
DEBUG=true
ZRAM_SIZE_MB=1024
USERLAND_USER="userland"
SYSTEM_UID=1000  # Default system UID

# ================ UTILITY FUNCTIONS ================ #
log() {
    local level=$1
    local message=$2
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[${timestamp}] [${level}] ${message}"
    if [[ -n "${LOG_FILE:-}" ]]; then
        echo "[${timestamp}] [${level}] ${message}" >> "${LOG_FILE}"
    fi
}

log_info() {
    log "INFO" "$1"
}

log_warn() {
    log "WARN" "$1"
}

log_error() {
    log "ERROR" "$1"
    [[ "${DEBUG}" == "true" ]] && backtrace
}

backtrace() {
    local i=0
    local FRAMES=${#BASH_SOURCE[@]}
    
    echo "=== Execution Backtrace ==="
    for ((i=1; i<FRAMES; i++)); do
        echo "  File: ${BASH_SOURCE[$i]}, Line: ${BASH_LINENO[$i-1]}, Function: ${FUNCNAME[$i]}"
    done
    echo "=========================="
}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

check_dependencies() {
    log_info "Checking for required dependencies..."
    local missing_deps=()
    
    local deps=(
        "unzip" "wget" "curl" "p7zip" "simg2img" "proot" 
        "util-linux" "lz4" "jq" "mount" "umount"
    )
    
    for dep in "${deps[@]}"; do
        if ! command_exists "$dep"; then
            missing_deps+=("$dep")
        fi
    done
    
    if [[ ${#missing_deps[@]} -gt 0 ]]; then
        log_error "Missing dependencies: ${missing_deps[*]}"
        log_info "Installing missing dependencies..."
        apt update
        for dep in "${missing_deps[@]}"; do
            apt install -y "$dep" || log_error "Failed to install $dep"
        done
    else
        log_info "All dependencies satisfied."
    fi
}

check_architecture() {
    local arch=$(uname -m)
    if [[ "$arch" != "aarch64" ]]; then
        log_error "Architecture must be aarch64/arm64, detected: $arch"
        exit 1
    fi
    log_info "Architecture validated: $arch"
}

create_directory_structure() {
    log_info "Creating directory structure..."
    mkdir -p "${CELL_BASE}"/{rootfs,overlay,workdir,system_ro,config,bin,lib,tmp}
    mkdir -p "$(dirname "${LOG_FILE}")"
    touch "${LOG_FILE}"
    log_info "Directory structure created."
}

check_android_version() {
    local android_version=$(getprop ro.build.version.release)
    if [[ -z "$android_version" ]]; then
        log_warn "Could not detect Android version. Proceeding anyway."
    elif [[ "$android_version" != "$ANDROID_VERSION" ]]; then
        log_warn "Warning: Host Android version ($android_version) differs from target ($ANDROID_VERSION). This may cause compatibility issues."
    else
        log_info "Android version validated: $android_version"
    fi
}

# ================ CHISEL SETUP FUNCTIONS ================ #
install_chisel() {
    log_info "Setting up Chisel..."
    local arch=$(uname -m)
    
    if [[ ! -f "${CELL_BASE}/bin/chisel" ]]; then
        log_info "Downloading Chisel ${CHISEL_VERSION} for ${arch}..."
        mkdir -p "${CELL_BASE}/bin"
        curl -L "https://github.com/canonical/chisel/releases/download/${CHISEL_VERSION}/chisel-${arch}" \
            -o "${CELL_BASE}/bin/chisel"
        chmod +x "${CELL_BASE}/bin/chisel"
    else
        log_info "Chisel already installed."
    fi
    
    # Verify Chisel installation
    if [[ ! -x "${CELL_BASE}/bin/chisel" ]]; then
        log_error "Failed to install Chisel properly."
        exit 1
    fi
    
    log_info "Chisel installed successfully."
}

# ================ FIRMWARE FUNCTIONS ================ #
download_firmware() {
    log_info "Preparing firmware..."
    
    if [[ -f "${FIRMWARE_ZIP}" ]]; then
        log_info "Using local firmware file: ${FIRMWARE_ZIP}"
    elif [[ -n "${FIRMWARE_URL}" ]]; then
        log_info "Downloading firmware from: ${FIRMWARE_URL}"
        wget -O "${FIRMWARE_ZIP}" "${FIRMWARE_URL}" || {
            log_error "Failed to download firmware."
            exit 1
        }
    else
        log_error "No firmware file or URL provided."
        exit 1
    fi
    
    if [[ ! -f "${FIRMWARE_ZIP}" ]]; then
        log_error "Firmware file not found: ${FIRMWARE_ZIP}"
        exit 1
    fi
    
    log_info "Firmware preparation complete."
}

extract_system_image() {
    log_info "Extracting system image from firmware..."
    local EXTRACT_DIR="${CELL_BASE}/tmp/extract"
    mkdir -p "${EXTRACT_DIR}"
    
    pushd "${EXTRACT_DIR}" > /dev/null
    
    # Try multiple extraction methods since firmware packaging can vary
    log_info "Attempting AP package extraction..."
    unzip -j "${FIRMWARE_ZIP}" "AP*.tar.md5" || {
        log_info "AP*.tar.md5 not found, trying alternative extraction..."
        unzip -j "${FIRMWARE_ZIP}" "*.tar.md5" || {
            log_info "*.tar.md5 not found, trying direct system.img extraction..."
            unzip -j "${FIRMWARE_ZIP}" "system.img*" || {
                log_error "Failed to extract system image from firmware."
                popd > /dev/null
                return 1
            }
        }
    }
    
    # Handle various packaging formats
    if [[ -f "system.img" ]]; then
        log_info "Found extracted system.img directly."
    elif [[ -f "system.img.lz4" ]]; then
        log_info "Found system.img.lz4, decompressing..."
        lz4 -d "system.img.lz4" system.img.raw || {
            log_error "Failed to decompress system.img.lz4"
            popd > /dev/null
            return 1
        }
    else
        # Extract from AP tar
        local TAR_FILE=$(find . -name "*.tar.md5" | head -n1)
        if [[ -z "${TAR_FILE}" ]]; then
            log_error "No tar.md5 file found after extraction."
            popd > /dev/null
            return 1
        fi
        
        log_info "Extracting system image from ${TAR_FILE}..."
        tar -xf "${TAR_FILE}" "system.img*" || tar -xf "${TAR_FILE}" || {
            log_error "Failed to extract from tar file."
            popd > /dev/null
            return 1
        }
    fi
    
    # Handle various image formats
    if [[ -f "system.img.lz4" && ! -f "system.img" ]]; then
        log_info "Decompressing system.img.lz4..."
        lz4 -d "system.img.lz4" "system.img.raw" || {
            log_error "Failed to decompress system.img.lz4"
            popd > /dev/null
            return 1
        }
    fi
    
    if [[ -f "system.img.raw" && ! -f "system.img" ]]; then
        log_info "Converting sparse image to raw..."
        simg2img "system.img.raw" "system.img" || {
            log_error "Failed to convert sparse image to raw format."
            popd > /dev/null
            return 1
        }
    fi
    
    if [[ ! -f "system.img" ]]; then
        log_error "system.img not found after extraction attempts."
        popd > /dev/null
        return 1
    fi
    
    # Move system.img to final location
    log_info "Moving system.img to final location..."
    mv "system.img" "${CELL_BASE}/system.img"
    
    popd > /dev/null
    log_info "System image extraction complete."
}

# ================ OVERLAY FILESYSTEM FUNCTIONS ================ #
setup_overlay_filesystem() {
    log_info "Setting up overlay filesystem..."
    
    # Mount system.img as read-only
    log_info "Mounting system image as read-only..."
    mount -o loop,ro "${CELL_BASE}/system.img" "${CELL_BASE}/system_ro" || {
        log_error "Failed to mount system image."
        return 1
    }
    
    # Create overlay mount
    log_info "Creating overlay mount..."
    mount -t overlay overlay \
        -o lowerdir="${CELL_BASE}/system_ro",upperdir="${CELL_BASE}/overlay",workdir="${CELL_BASE}/workdir" \
        "${CELL_BASE}/rootfs" || {
        log_error "Failed to create overlay mount."
        umount "${CELL_BASE}/system_ro" 2>/dev/null || true
        return 1
    }
    
    log_info "Overlay filesystem setup complete."
}

# ================ ZRAM FUNCTIONS ================ #
setup_zram_configuration() {
    log_info "Setting up ZRAM configuration..."
    
    # Create ZRAM configuration directory
    mkdir -p "${CELL_BASE}/rootfs/etc/zram-config" "${CELL_BASE}/rootfs/etc/init.d"
    
    # Create ZRAM configuration file
    cat > "${CELL_BASE}/rootfs/etc/zram-config/zram-config.conf" << EOF
# ZRAM Configuration with Samsung optimizations
ZRAM_NUM_DEVICES=2
ZRAM_SIZE_MB=${ZRAM_SIZE_MB}
ZRAM_ALGORITHM=lz4
ZRAM_PRIORITY=100
ZRAM_STREAMS=$(nproc)
EOF
    
    # Create ZRAM initialization script
    cat > "${CELL_BASE}/rootfs/etc/init.d/zram-config" << EOF
#!/bin/sh
### BEGIN INIT INFO
# Provides:          zram-config
# Required-Start:    $local_fs
# Required-Stop:     $local_fs
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: ZRAM configuration with Samsung optimizations
### END INIT INFO

. /etc/zram-config/zram-config.conf

start_zram() {
    modprobe zram num_devices=\${ZRAM_NUM_DEVICES:-2}
    
    for i in \$(seq 0 \$((ZRAM_NUM_DEVICES-1))); do
        # Samsung-specific optimizations
        if [ -f "/sys/block/zram\$i/use_dedup" ]; then
            echo "1" > /sys/block/zram\$i/use_dedup
        fi
        
        if [ -f "/sys/block/zram\$i/comp_algorithm" ]; then
            echo "\${ZRAM_ALGORITHM:-lz4}" > /sys/block/zram\$i/comp_algorithm
        fi
        
        if [ -f "/sys/block/zram\$i/max_comp_streams" ]; then
            echo "\${ZRAM_STREAMS:-1}" > /sys/block/zram\$i/max_comp_streams
        fi
        
        echo \$((ZRAM_SIZE_MB*1024*1024)) > /sys/block/zram\$i/disksize
        mkswap /dev/zram\$i
        swapon -p \${ZRAM_PRIORITY:-100} /dev/zram\$i
    done
    
    echo "ZRAM devices configured: \${ZRAM_NUM_DEVICES}"
}

stop_zram() {
    for i in \$(seq 0 \$((ZRAM_NUM_DEVICES-1))); do
        if [ -b "/dev/zram\$i" ]; then
            swapoff /dev/zram\$i || true
        fi
    done
    
    if lsmod | grep -q zram; then
        rmmod zram || true
    fi
    
    echo "ZRAM devices stopped"
}

case "\$1" in
    start)
        start_zram
        ;;
    stop)
        stop_zram
        ;;
    restart)
        stop_zram
        start_zram
        ;;
    *)
        echo "Usage: \$0 {start|stop|restart}"
        exit 1
        ;;
esac

exit 0
EOF
    
    chmod +x "${CELL_BASE}/rootfs/etc/init.d/zram-config"
    
    # Create symlinks for auto-start
    mkdir -p "${CELL_BASE}/rootfs/etc/rc3.d"
    ln -sf "../init.d/zram-config" "${CELL_BASE}/rootfs/etc/rc3.d/S01zram-config"
    
    log_info "ZRAM configuration setup complete."
}

# ================ CONTAINER CONFIGURATION FUNCTIONS ================ #
create_container_config() {
    log_info "Creating container configuration..."
    
    mkdir -p "${CELL_BASE}/config"
    
    cat > "${CELL_BASE}/config/config.json" << EOF
{
  "ociVersion": "1.0.0",
  "process": {
    "terminal": true,
    "user": {
      "uid": 0,
      "gid": 0
    },
    "args": ["/bin/sh"],
    "env": [
      "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
      "TERM=xterm",
      "ANDROID_VERSION=${ANDROID_VERSION}",
      "HOME=/root",
      "ZRAM_SIZE_MB=${ZRAM_SIZE_MB}"
    ],
    "cwd": "/",
    "capabilities": {
      "bounding": [
        "CAP_AUDIT_WRITE",
        "CAP_CHOWN",
        "CAP_DAC_OVERRIDE",
        "CAP_FOWNER",
        "CAP_FSETID",
        "CAP_KILL",
        "CAP_MKNOD",
        "CAP_NET_BIND_SERVICE",
        "CAP_NET_RAW",
        "CAP_SETFCAP",
        "CAP_SETGID",
        "CAP_SETPCAP",
        "CAP_SETUID",
        "CAP_SYS_CHROOT"
      ],
      "effective": [
        "CAP_AUDIT_WRITE",
        "CAP_CHOWN",
        "CAP_DAC_OVERRIDE",
        "CAP_FOWNER",
        "CAP_FSETID",
        "CAP_KILL",
        "CAP_MKNOD",
        "CAP_NET_BIND_SERVICE",
        "CAP_NET_RAW",
        "CAP_SETFCAP",
        "CAP_SETGID",
        "CAP_SETPCAP",
        "CAP_SETUID",
        "CAP_SYS_CHROOT"
      ],
      "inheritable": [
        "CAP_AUDIT_WRITE",
        "CAP_KILL",
        "CAP_NET_BIND_SERVICE"
      ],
      "permitted": [
        "CAP_AUDIT_WRITE",
        "CAP_CHOWN",
        "CAP_DAC_OVERRIDE",
        "CAP_FOWNER",
        "CAP_FSETID",
        "CAP_KILL",
        "CAP_MKNOD",
        "CAP_NET_BIND_SERVICE",
        "CAP_NET_RAW",
        "CAP_SETFCAP",
        "CAP_SETGID",
        "CAP_SETPCAP",
        "CAP_SETUID",
        "CAP_SYS_CHROOT"
      ]
    },
    "rlimits": [
      {
        "type": "RLIMIT_NOFILE",
        "hard": 1024,
        "soft": 1024
      }
    ]
  },
  "root": {
    "path": "${CELL_BASE}/rootfs",
    "readonly": false
  },
  "mounts": [
    {
      "destination": "/proc",
      "type": "proc",
      "source": "proc"
    },
    {
      "destination": "/dev",
      "type": "tmpfs",
      "source": "tmpfs",
      "options": ["nosuid", "strictatime", "mode=755", "size=65536k"]
    },
    {
      "destination": "/dev/pts",
      "type": "devpts",
      "source": "devpts",
      "options": ["nosuid", "noexec", "newinstance", "ptmxmode=0666", "mode=0620"]
    },
    {
      "destination": "/dev/shm",
      "type": "tmpfs",
      "source": "shm",
      "options": ["nosuid", "noexec", "nodev", "mode=1777", "size=65536k"]
    },
    {
      "destination": "/sys",
      "type": "sysfs",
      "source": "sysfs",
      "options": ["nosuid", "noexec", "nodev", "ro"]
    },
    {
      "destination": "/sys/fs/cgroup",
      "type": "cgroup",
      "source": "cgroup",
      "options": ["nosuid", "noexec", "nodev", "relatime", "ro"]
    }
  ],
  "linux": {
    "resources": {
      "devices": [
        {
          "allow": false,
          "access": "rwm"
        }
      ],
      "memory": {
        "limit": $((ZRAM_SIZE_MB * 1024 * 1024)),
        "reservation": $((ZRAM_SIZE_MB * 1024 * 1024 / 2)),
        "swap": $((ZRAM_SIZE_MB * 1024 * 1024)),
        "swappiness": 60
      },
      "cpu": {
        "shares": 1024,
        "quota": 100000,
        "period": 100000
      }
    },
    "namespaces": [
      {
        "type": "pid"
      },
      {
        "type": "network"
      },
      {
        "type": "ipc"
      },
      {
        "type": "uts"
      },
      {
        "type": "mount"
      }
    ]
  }
}
EOF
    
    log_info "Container configuration created."
}

# ================ USERLAND INTEGRATION FUNCTIONS ================ #
setup_userland_integration() {
    log_info "Setting up UserLAnd integration..."
    
    # Create directory for UserLAnd integration
    mkdir -p "${CELL_BASE}/userland"
    
    # Create UserLAnd launcher script
    cat > "${CELL_BASE}/userland/launch.sh" << EOF
#!/bin/bash
set -euo pipefail

CELL_BASE="${CELL_BASE}"
USERLAND_USER="${USERLAND_USER}"

# Check if we're running in UserLAnd
if [[ "\$(whoami)" != "${USERLAND_USER}" ]]; then
    echo "This script should be run within UserLAnd environment."
    exit 1
fi

# Ensure necessary directories exist
mkdir -p "\${CELL_BASE}"

# Copy this script to UserLAnd home directory for convenience
cp "\$0" ~/userland_launch.sh
chmod +x ~/userland_launch.sh

# Execute the container
echo "Launching isolated Android environment..."
"\${CELL_BASE}/bin/chisel" run -config "\${CELL_BASE}/config/config.json" /bin/sh

exit 0
EOF
    
    chmod +x "${CELL_BASE}/userland/launch.sh"
    
    log_info "UserLAnd integration setup complete."
}

# ================ ENTRY POINT CREATION ================ #
create_entry_script() {
    log_info "Creating entry script..."
    
    cat > "${CELL_BASE}/enter_isolated_android.sh" << EOF
#!/system/bin/sh
# Entry script for isolated Android environment
# This script handles mounting and entering the isolated environment

CELL_BASE="${CELL_BASE}"
DEBUG=${DEBUG}

log() {
    echo "[\$(date '+%Y-%m-%d %H:%M:%S')] \$1"
}

mount_overlay() {
    if ! mountpoint -q "\${CELL_BASE}/rootfs"; then
        log "Mounting overlay filesystem..."
        mount -t overlay overlay \\
            -o lowerdir="\${CELL_BASE}/system_ro",upperdir="\${CELL_BASE}/overlay",workdir="\${CELL_BASE}/workdir" \\
            "\${CELL_BASE}/rootfs" || {
            log "Failed to mount overlay filesystem."
            return 1
        }
        log "Overlay filesystem mounted."
    else
        log "Overlay filesystem already mounted."
    fi
    return 0
}

unmount_all() {
    log "Unmounting all filesystems..."
    umount "\${CELL_BASE}/rootfs" 2>/dev/null || true
    umount "\${CELL_BASE}/system_ro" 2>/dev/null || true
    log "Filesystems unmounted."
}

check_system_image() {
    if [ ! -f "\${CELL_BASE}/system.img" ]; then
        log "System image not found at \${CELL_BASE}/system.img"
        return 1
    fi
    return 0
}

mount_system_image() {
    if ! mountpoint -q "\${CELL_BASE}/system_ro"; then
        log "Mounting system image..."
        mount -o loop,ro "\${CELL_BASE}/system.img" "\${CELL_BASE}/system_ro" || {
            log "Failed to mount system image."
            return 1
        }
        log "System image mounted."
    else
        log "System image already mounted."
    fi
    return 0
}

start_isolated_environment() {
    log "Starting isolated Android environment..."
    
    # Check system image
    check_system_image || {
        log "System image check failed. Please run setup first."
        return 1
    }
    
    # Mount system image
    mount_system_image || {
        log "System image mount failed."
        return 1
    }
    
    # Mount overlay
    mount_overlay || {
        log "Overlay mount failed."
        unmount_all
        return 1
    }
    
    # Enter isolated environment using proot
    log "Entering isolated environment..."
    exec proot -r "\${CELL_BASE}/rootfs" \\
        -b /dev \\
        -b /proc \\
        -w / \\
        /system/bin/sh
}

case "\$1" in
    start)
        start_isolated_environment
        ;;
    stop)
        unmount_all
        ;;
    restart)
        unmount_all
        start_isolated_environment
        ;;
    *)
        # Default action is to start
        start_isolated_environment
        ;;
esac

exit 0
EOF
    
    chmod +x "${CELL_BASE}/enter_isolated_android.sh"
    
    log_info "Entry script created."
}

# ================ CLEANUP FUNCTIONS ================ #
cleanup() {
    log_info "Performing cleanup..."
    
    # Unmount any mounted filesystems
    umount "${CELL_BASE}/rootfs" 2>/dev/null || true
    umount "${CELL_BASE}/system_ro" 2>/dev/null || true
    
    # Remove temporary files
    rm -rf "${CELL_BASE}/tmp" 2>/dev/null || true
    
    log_info "Cleanup complete."
}

# ================ MAIN FUNCTION ================ #
main() {
    log_info "Starting isolated Android environment setup..."
    
    # Check architecture
    check_architecture
    
    # Check Android version
    check_android_version
    
    # Create directory structure
    create_directory_structure
    
    # Check dependencies
    check_dependencies
    
    # Install Chisel
    install_chisel
    
    # Download firmware
    download_firmware
    
    # Extract system image
    extract_system_image || {
        log_error "Failed to extract system image."
        cleanup
        exit 1
    }
    
    # Setup overlay filesystem
    setup_overlay_filesystem || {
        log_error "Failed to setup overlay filesystem."
        cleanup
        exit 1
    }
    
    # Setup ZRAM configuration
    setup_zram_configuration
    
    # Create container config
    create_container_config
    
    # Setup UserLAnd integration
    setup_userland_integration
    
    # Create entry script
    create_entry_script
    
    # Cleanup temporary files
    cleanup
    
    log_info "======================================================"
    log_info "ISOLATED ANDROID ENVIRONMENT SETUP COMPLETE"
    log_info "======================================================"
    log_info "To enter the environment, run:"
    log_info "${CELL_BASE}/enter_isolated_android.sh"
    log_info ""
    log_info "For UserLAnd integration:"
    log_info "1. Copy ${CELL_BASE}/userland/launch.sh to UserLAnd"
    log_info "2. Run the script within UserLAnd"
    log_info "======================================================"
}

# Execute main function
main "$@"