/**
 * Android Hypervisor Isolation Framework (AHIF) Userspace Controller
 * 
 * Provides userspace control interface for the kernel isolation framework
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <sys/mount.h>
#include <sys/syscall.h>
#include <sched.h>

/* AHIF control device */
#define AHIF_DEVICE "/dev/ahif"

/* AHIF commands */
#define AHIF_CMD_START        _IOW('A', 1, struct ahif_start_params)
#define AHIF_CMD_STOP         _IO('A', 2)
#define AHIF_CMD_STATUS       _IOR('A', 3, struct ahif_status)
#define AHIF_CMD_ENTER_SHELL  _IO('A', 4)

/* Command parameters */
struct ahif_start_params {
    char system_img[256];
    char overlay_dir[256];
    char data_dir[256];
    unsigned int flags;
    unsigned int mem_limit_mb;
};

struct ahif_status {
    int running;
    int pid;
    unsigned int mem_used_kb;
    unsigned int zram_used_kb;
    unsigned int zram_saved_kb;
};

/**
 * Print usage information
 */
static void print_usage(const char *prog_name)
{
    printf("Usage: %s COMMAND [OPTIONS]\n\n", prog_name);
    printf("Commands:\n");
    printf("  start [OPTIONS]    Start the isolated environment\n");
    printf("  stop               Stop the isolated environment\n");
    printf("  status             Show status of the isolated environment\n");
    printf("  shell              Enter the isolated environment shell\n");
    printf("\nStart options:\n");
    printf("  -s, --system IMG   System image path (required)\n");
    printf("  -o, --overlay DIR  Overlay directory path (required)\n");
    printf("  -d, --data DIR     Data directory path (required)\n");
    printf("  -m, --memory MB    Memory limit in MB (default: 2048)\n");
    printf("  -z, --zram         Enable ZRAM compression\n");
    printf("  -k, --secure-boot  Enable secure boot verification\n");
}

/**
 * Start the isolated environment
 */
static int cmd_start(int argc, char *argv[])
{
    int fd, ret;
    struct ahif_start_params params;
    int i;
    
    /* Parse arguments */
    memset(&params, 0, sizeof(params));
    params.mem_limit_mb = 2048;
    
    for (i = 2; i < argc; i++) {
        if (strcmp(argv[i], "-s") == 0 || strcmp(argv[i], "--system") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: Missing system image path\n");
                return -1;
            }
            strncpy(params.system_img, argv[++i], sizeof(params.system_img) - 1);
        } else if (strcmp(argv[i], "-o") == 0 || strcmp(argv[i], "--overlay") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: Missing overlay directory path\n");
                return -1;
            }
            strncpy(params.overlay_dir, argv[++i], sizeof(params.overlay_dir) - 1);
        } else if (strcmp(argv[i], "-d") == 0 || strcmp(argv[i], "--data") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: Missing data directory path\n");
                return -1;
            }
            strncpy(params.data_dir, argv[++i], sizeof(params.data_dir) - 1);
        } else if (strcmp(argv[i], "-m") == 0 || strcmp(argv[i], "--memory") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: Missing memory limit\n");
                return -1;
            }
            params.mem_limit_mb = atoi(argv[++i]);
        } else if (strcmp(argv[i], "-z") == 0 || strcmp(argv[i], "--zram") == 0) {
            params.flags |= 1;  /* AHIF_FLAG_USE_ZRAM */
        } else if (strcmp(argv[i], "-k") == 0 || strcmp(argv[i], "--secure-boot") == 0) {
            params.flags |= 2;  /* AHIF_FLAG_SECURE_BOOT */
        } else {
            fprintf(stderr, "Error: Unknown option: %s\n", argv[i]);
            return -1;
        }
    }
    
    /* Check required parameters */
    if (params.system_img[0] == '\0') {
        fprintf(stderr, "Error: System image path required\n");
        return -1;
    }
    
    if (params.overlay_dir[0] == '\0') {
        fprintf(stderr, "Error: Overlay directory path required\n");
        return -1;
    }
    
    if (params.data_dir[0] == '\0') {
        fprintf(stderr, "Error: Data directory path required\n");
        return -1;
    }
    
    /* Open AHIF device */
    fd = open(AHIF_DEVICE, O_RDWR);
    if (fd < 0) {
        perror("Failed to open AHIF device");
        return -1;
    }
    
    /* Send start command */
    ret = ioctl(fd, AHIF_CMD_START, &params);
    if (ret < 0) {
        perror("Failed to start isolated environment");
        close(fd);
        return -1;
    }
    
    printf("Isolated environment started successfully\n");
    close(fd);
    return 0;
}

/**
 * Stop the isolated environment
 */
static int cmd_stop(void)
{
    int fd, ret;
    
    /* Open AHIF device */
    fd = open(AHIF_DEVICE, O_RDWR);
    if (fd < 0) {
        perror("Failed to open AHIF device");
        return -1;
    }
    
    /* Send stop command */
    ret = ioctl(fd, AHIF_CMD_STOP);
    if (ret < 0) {
        perror("Failed to stop isolated environment");
        close(fd);
        return -1;
    }
    
    printf("Isolated environment stopped successfully\n");
    close(fd);
    return 0;
}

/**
 * Show status of the isolated environment
 */
static int cmd_status(void)
{
    int fd, ret;
    struct ahif_status status;
    
    /* Open AHIF device */
    fd = open(AHIF_DEVICE, O_RDWR);
    if (fd < 0) {
        perror("Failed to open AHIF device");
        return -1;
    }
    
    /* Send status command */
    ret = ioctl(fd, AHIF_CMD_STATUS, &status);
    if (ret < 0) {
        perror("Failed to get environment status");
        close(fd);
        return -1;
    }
    
    /* Display status */
    printf("Isolated Environment Status\n");
    printf("---------------------------\n");
    printf("Status: %s\n", status.running ? "Running" : "Stopped");
    
    if (status.running) {
        printf("PID: %d\n", status.pid);
        printf("Memory usage: %u KB\n", status.mem_used_kb);
        printf("ZRAM usage: %u KB\n", status.zram_used_kb);
        printf("ZRAM memory saved: %u KB\n", status.zram_saved_kb);
        
        /* Show SSH tunnel info if available */
        printf("\nSSH Tunnel: Enabled\n");
        printf("Connection: ssh -p 2022 -i ~/.ssh/ahif_key root@localhost\n");
    }
    
    close(fd);
    return 0;
}

/**
 * Enter the isolated environment shell
 */
static int cmd_enter_shell(void)
{
    int fd, ret;
    
    /* Open AHIF device */
    fd = open(AHIF_DEVICE, O_RDWR);
    if (fd < 0) {
        perror("Failed to open AHIF device");
        return -1;
    }
    
    printf("Entering isolated environment shell...\n");
    
    /* Send enter shell command */
    ret = ioctl(fd, AHIF_CMD_ENTER_SHELL);
    if (ret < 0) {
        perror("Failed to enter shell");
        close(fd);
        return -1;
    }
    
    close(fd);
    return 0;
}

/**
 * Main function
 */
int main(int argc, char *argv[])
{
    /* Check for arguments */
    if (argc < 2) {
        print_usage(argv[0]);
        return 1;
    }
    
    /* Process commands */
    if (strcmp(argv[1], "start") == 0) {
        return cmd_start(argc, argv);
    } else if (strcmp(argv[1], "stop") == 0) {
        return cmd_stop();
    } else if (strcmp(argv[1], "status") == 0) {
        return cmd_status();
    } else if (strcmp(argv[1], "shell") == 0) {
        return cmd_enter_shell();
    } else {
        fprintf(stderr, "Error: Unknown command: %s\n", argv[1]);
        print_usage(argv[0]);
        return 1;
    }
}