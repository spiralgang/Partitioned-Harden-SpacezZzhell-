# Advanced Git Commands: Usage and Examples

This guide explains several advanced Git commands, their practical usage, and demonstrates each with concrete examples. These commands are vital for robust version control, team productivity, and incident recovery in production-grade workflows.

---

## 1. `git stash`

**Purpose:**  
Temporarily shelves (stashes) changes in your working directory that are not yet ready to be committed, so you can work on something else, then re-apply them later.

**Typical Use Cases:**
- You need to quickly switch branches but have uncommitted changes you don't want to commit yet.
- Experimenting, but you want a clean working directory.

**Key Variants:**
- `git stash` — Save both staged and unstaged changes.
- `git stash --keep-index` — Stash unstaged changes only, keep staged changes.
- `git stash pop` — Apply the most recent stash and remove it from stash list.
- `git stash apply` — Apply the most recent stash but keep it in stash list.

**Example:**
```sh
# Save your local modifications to a new stash
git stash

# List all stashed changes
git stash list

# Re-apply the most recent stash
git stash pop

# Apply a specific stash without removing it from the stash list
git stash apply stash@{1}
```

---

## 2. `git cherry-pick`

**Purpose:**  
Apply the changes introduced by some existing commits onto your current branch. Useful for moving just a few specific commits from one branch to another.

**Typical Use Cases:**
- Backporting bug fixes to a maintenance branch.
- Applying a feature/fix from one branch onto another without merging the whole branch.

**Key Variants:**
- `git cherry-pick <commit>` — Apply the specified commit.
- `git cherry-pick <commit1> <commit2>` — Apply multiple commits.
- `git cherry-pick <commitA>^..<commitB>` — Apply a range of commits.

**Example:**
```sh
# Apply a specific commit to your current branch
git cherry-pick 1a2b3c4d

# Cherry-pick a range of commits
git cherry-pick 1a2b3c4d^..5e6f7g8h
```

---

## 3. `git revert`

**Purpose:**  
Create a new commit that undoes the changes of a previous commit. This is the safest way to "undo" a commit, especially on public branches.

**Typical Use Cases:**
- Reversing a problematic commit while keeping history linear and transparent.
- Undoing changes in shared/public history.

**Key Variants:**
- `git revert <commit>` — Revert the given commit.
- `git revert --no-commit <commit>` — Revert, but don't commit immediately (stages changes).
- `git revert <commitA>..<commitB>` — Revert a range of commits.

**Example:**
```sh
# Revert a single commit
git revert 1a2b3c4d

# Revert multiple commits (creates one revert commit per original commit)
git revert 1a2b3c4d 5e6f7g8h
```

---

## 4. `git reset`

**Purpose:**  
Moves the current branch pointer and (optionally) modifies the staging area and/or working directory to match. Powerful for rewriting local history or undoing changes, but dangerous on shared branches.

**Types of Reset:**
- `--soft` — Moves HEAD, does not touch index or working directory.
- `--mixed` (default) — Moves HEAD and updates index (unstages changes), working directory unchanged.
- `--hard` — Moves HEAD, updates index and working directory (all changes lost).

**Typical Use Cases:**
- Undoing commits in local history (before pushing).
- Unstaging files.
- Completely discarding local changes.

**Key Variants:**
- `git reset --soft <commit>`
- `git reset --mixed <commit>`
- `git reset --hard <commit>`

**Example:**
```sh
# Move HEAD back by one commit, keep changes staged
git reset --soft HEAD~1

# Move HEAD back by one commit, unstage changes but keep them in working directory
git reset --mixed HEAD~1

# Move HEAD back by one commit, discard all changes
git reset --hard HEAD~1
```

---

## References

- [Git Documentation](https://git-scm.com/doc)
- [Pro Git Book](https://git-scm.com/book/en/v2)
- [Reference Vault](/reference/vault)

---